#ifndef SCHEDULETASK_NEW_H
#define SCHEDULETASK_NEW_H

#include <Arduino.h>
#include <ArduinoJson.h>
#include <commonvar.h>
#include <commondef.h>

bool schedule_task();

#endif