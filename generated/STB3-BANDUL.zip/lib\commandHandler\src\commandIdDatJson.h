const char* commandIdDatJson = R"(
{
    "5": "pom_data"
}
)";
