const char* setupExeJson = R"(
[]
)";
