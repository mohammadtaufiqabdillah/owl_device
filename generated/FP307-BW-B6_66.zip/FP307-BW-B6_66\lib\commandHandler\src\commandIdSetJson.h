const char* commandIdSetJson = R"___(
{
    "6": "wifi",
    "7": "mqtt",
    "9": "testing"
}
)___";
