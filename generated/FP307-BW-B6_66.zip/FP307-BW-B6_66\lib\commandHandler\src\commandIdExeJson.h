const char* commandIdExeJson = R"___(
{
    "3": "exe_proof",
    "6": "restart"
}
)___";
