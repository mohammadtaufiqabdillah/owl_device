const char* setupExeJson = R"___(
{
    "3": "exe_proof",
    "6": "restart"
}
)___";
