#ifndef TEMPNOW_H_
#define TEMPNOW_H_

#include <commonvar.h>
#include <commondef.h>
#include <esp_now.h>
#include <WiFi.h>
#include <esp_wifi.h>

bool tempnow_task();

#endif