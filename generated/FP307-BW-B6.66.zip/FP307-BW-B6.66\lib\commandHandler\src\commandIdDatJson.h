const char* commandIdDatJson = R"___(
{
    "5": "pom_data"
}
)___";
