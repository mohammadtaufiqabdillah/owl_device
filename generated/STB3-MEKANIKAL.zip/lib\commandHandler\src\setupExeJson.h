const char* setupExeJson = R"(
[]
)";