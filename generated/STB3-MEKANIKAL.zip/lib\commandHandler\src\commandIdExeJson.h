const char* commandIdExeJson = R"(
[]
)";