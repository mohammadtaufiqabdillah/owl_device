const char* commandIdSetJson = R"(
[]
)";