const char* setupSetJson = R"(
[]
)";