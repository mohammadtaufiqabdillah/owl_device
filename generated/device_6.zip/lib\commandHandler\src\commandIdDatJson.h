const char* commandIdDatJson = R"(
{
    "1": "pom_data",
    "2": "radio_pooling_data",
    "3": "bandul_data",
    "4": "logger_gps_data",
    "5": "logger_vehicle_gps_data",
    "6": "radio_broadcast_data",
    "7": "radio_join_data",
    "8": "radio_response_data",
    "9": "stb_notification",
    "10": "stb_sounding_data",
    "11": "soil_data",
    "12": "stb_data_air"
}
)";
