const char* commandIdSetJson = R"(
[]
)";
