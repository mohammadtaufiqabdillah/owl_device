const char* setupSetJson = R"(
[]
)";
