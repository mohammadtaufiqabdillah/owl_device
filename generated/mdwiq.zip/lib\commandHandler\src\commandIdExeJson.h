const char* commandIdExeJson = R"(
[]
)";
