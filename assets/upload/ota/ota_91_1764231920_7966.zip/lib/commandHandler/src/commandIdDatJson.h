const char* commandIdDatJson=R"(
{
    "1": "pom_data",
    "2": "radio_pooling_data",
    "3": "bandul_data",
    "4": "logger_gps_data",
    "6": "logger_vehicle_gps_data",
    "7": "radio_broadcast_data",
    "8": "radio_join_data",
    "9": "radio_response_data",
    "10": "stb_notification",
    "11": "stb_sounding_data",
    "12": "soil_data",
    "13": "stb_data_air"
}
)";