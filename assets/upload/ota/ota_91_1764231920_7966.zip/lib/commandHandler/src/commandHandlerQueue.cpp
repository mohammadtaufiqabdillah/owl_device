#include "CommandHandler.h"

SemaphoreHandle_t mutex_handler;

// Queue Initializations
QueueHandle_t wifiQueue;
QueueHandle_t mqttQueue;
QueueHandle_t intervalQueue;
QueueHandle_t utcoffsetQueue;
QueueHandle_t last_epochQueue;
QueueHandle_t keyQueue;
QueueHandle_t use_keyQueue;
QueueHandle_t snQueue;
QueueHandle_t otaurlQueue;
QueueHandle_t api_ver1Queue;
QueueHandle_t api_ver2Queue;
QueueHandle_t adv_bleQueue;
QueueHandle_t radio_modeQueue;
QueueHandle_t radio_param_1Queue;
QueueHandle_t radio_param_2Queue;
QueueHandle_t radio_param_3Queue;
QueueHandle_t radio_param_4Queue;
QueueHandle_t licenseQueue;
QueueHandle_t suspendQueue;
QueueHandle_t hierarchy_setupQueue;
QueueHandle_t fingerprint_setupQueue;
QueueHandle_t stb_bandul_setupQueue;
QueueHandle_t pom_setupQueue;
QueueHandle_t stb_controller_setupQueue;
QueueHandle_t stb_mekanikal_setupQueue;
QueueHandle_t tracker_setupQueue;
QueueHandle_t stb_controller_sub_setupQueue;
QueueHandle_t esp_nowQueue;
QueueHandle_t functional_flagQueue;


// Initialize the queue
void CommandHandler::queueBegin(){
    mutex_handler = xSemaphoreCreateRecursiveMutex(); 
        wifiQueue = xQueueCreate(1, 1);
    mqttQueue = xQueueCreate(1, 1);
    intervalQueue = xQueueCreate(1, 1);
    utcoffsetQueue = xQueueCreate(1, 1);
    last_epochQueue = xQueueCreate(1, 1);
    keyQueue = xQueueCreate(1, 1);
    use_keyQueue = xQueueCreate(1, 1);
    snQueue = xQueueCreate(1, 1);
    otaurlQueue = xQueueCreate(1, 1);
    api_ver1Queue = xQueueCreate(1, 1);
    api_ver2Queue = xQueueCreate(1, 1);
    adv_bleQueue = xQueueCreate(1, 1);
    radio_modeQueue = xQueueCreate(1, 1);
    radio_param_1Queue = xQueueCreate(1, 1);
    radio_param_2Queue = xQueueCreate(1, 1);
    radio_param_3Queue = xQueueCreate(1, 1);
    radio_param_4Queue = xQueueCreate(1, 1);
    licenseQueue = xQueueCreate(1, 1);
    suspendQueue = xQueueCreate(1, 1);
    hierarchy_setupQueue = xQueueCreate(1, 1);
    fingerprint_setupQueue = xQueueCreate(1, 1);
    stb_bandul_setupQueue = xQueueCreate(1, 1);
    pom_setupQueue = xQueueCreate(1, 1);
    stb_controller_setupQueue = xQueueCreate(1, 1);
    stb_mekanikal_setupQueue = xQueueCreate(1, 1);
    tracker_setupQueue = xQueueCreate(1, 1);
    stb_controller_sub_setupQueue = xQueueCreate(1, 1);
    esp_nowQueue = xQueueCreate(1, 1);
    functional_flagQueue = xQueueCreate(1, 1);

}

// Send settings to the specified RTOS queue
void CommandHandler::sendToQueue(const char* queueName, bool status) {
    JsonDocument doc;
    bool newValues = status;

    if (strcmp(queueName, "wifiqueue") == 0) {
    if (wifiQueue != NULL) {
        xQueueOverwrite(wifiQueue, &newValues);
    }
}
else if (strcmp(queueName, "mqttqueue") == 0) {
    if (mqttQueue != NULL) {
        xQueueOverwrite(mqttQueue, &newValues);
    }
}
else if (strcmp(queueName, "intervalqueue") == 0) {
    if (intervalQueue != NULL) {
        xQueueOverwrite(intervalQueue, &newValues);
    }
}
else if (strcmp(queueName, "utcoffsetqueue") == 0) {
    if (utcoffsetQueue != NULL) {
        xQueueOverwrite(utcoffsetQueue, &newValues);
    }
}
else if (strcmp(queueName, "last_epochqueue") == 0) {
    if (last_epochQueue != NULL) {
        xQueueOverwrite(last_epochQueue, &newValues);
    }
}
else if (strcmp(queueName, "keyqueue") == 0) {
    if (keyQueue != NULL) {
        xQueueOverwrite(keyQueue, &newValues);
    }
}
else if (strcmp(queueName, "use_keyqueue") == 0) {
    if (use_keyQueue != NULL) {
        xQueueOverwrite(use_keyQueue, &newValues);
    }
}
else if (strcmp(queueName, "snqueue") == 0) {
    if (snQueue != NULL) {
        xQueueOverwrite(snQueue, &newValues);
    }
}
else if (strcmp(queueName, "otaurlqueue") == 0) {
    if (otaurlQueue != NULL) {
        xQueueOverwrite(otaurlQueue, &newValues);
    }
}
else if (strcmp(queueName, "api_ver1queue") == 0) {
    if (api_ver1Queue != NULL) {
        xQueueOverwrite(api_ver1Queue, &newValues);
    }
}
else if (strcmp(queueName, "api_ver2queue") == 0) {
    if (api_ver2Queue != NULL) {
        xQueueOverwrite(api_ver2Queue, &newValues);
    }
}
else if (strcmp(queueName, "adv_blequeue") == 0) {
    if (adv_bleQueue != NULL) {
        xQueueOverwrite(adv_bleQueue, &newValues);
    }
}
else if (strcmp(queueName, "radio_modequeue") == 0) {
    if (radio_modeQueue != NULL) {
        xQueueOverwrite(radio_modeQueue, &newValues);
    }
}
else if (strcmp(queueName, "radio_param_1queue") == 0) {
    if (radio_param_1Queue != NULL) {
        xQueueOverwrite(radio_param_1Queue, &newValues);
    }
}
else if (strcmp(queueName, "radio_param_2queue") == 0) {
    if (radio_param_2Queue != NULL) {
        xQueueOverwrite(radio_param_2Queue, &newValues);
    }
}
else if (strcmp(queueName, "radio_param_3queue") == 0) {
    if (radio_param_3Queue != NULL) {
        xQueueOverwrite(radio_param_3Queue, &newValues);
    }
}
else if (strcmp(queueName, "radio_param_4queue") == 0) {
    if (radio_param_4Queue != NULL) {
        xQueueOverwrite(radio_param_4Queue, &newValues);
    }
}
else if (strcmp(queueName, "licensequeue") == 0) {
    if (licenseQueue != NULL) {
        xQueueOverwrite(licenseQueue, &newValues);
    }
}
else if (strcmp(queueName, "suspendqueue") == 0) {
    if (suspendQueue != NULL) {
        xQueueOverwrite(suspendQueue, &newValues);
    }
}
else if (strcmp(queueName, "hierarchy_setupqueue") == 0) {
    if (hierarchy_setupQueue != NULL) {
        xQueueOverwrite(hierarchy_setupQueue, &newValues);
    }
}
else if (strcmp(queueName, "fingerprint_setupqueue") == 0) {
    if (fingerprint_setupQueue != NULL) {
        xQueueOverwrite(fingerprint_setupQueue, &newValues);
    }
}
else if (strcmp(queueName, "stb_bandul_setupqueue") == 0) {
    if (stb_bandul_setupQueue != NULL) {
        xQueueOverwrite(stb_bandul_setupQueue, &newValues);
    }
}
else if (strcmp(queueName, "pom_setupqueue") == 0) {
    if (pom_setupQueue != NULL) {
        xQueueOverwrite(pom_setupQueue, &newValues);
    }
}
else if (strcmp(queueName, "stb_controller_setupqueue") == 0) {
    if (stb_controller_setupQueue != NULL) {
        xQueueOverwrite(stb_controller_setupQueue, &newValues);
    }
}
else if (strcmp(queueName, "stb_mekanikal_setupqueue") == 0) {
    if (stb_mekanikal_setupQueue != NULL) {
        xQueueOverwrite(stb_mekanikal_setupQueue, &newValues);
    }
}
else if (strcmp(queueName, "tracker_setupqueue") == 0) {
    if (tracker_setupQueue != NULL) {
        xQueueOverwrite(tracker_setupQueue, &newValues);
    }
}
else if (strcmp(queueName, "stb_controller_sub_setupqueue") == 0) {
    if (stb_controller_sub_setupQueue != NULL) {
        xQueueOverwrite(stb_controller_sub_setupQueue, &newValues);
    }
}
else if (strcmp(queueName, "esp_nowqueue") == 0) {
    if (esp_nowQueue != NULL) {
        xQueueOverwrite(esp_nowQueue, &newValues);
    }
}
else if (strcmp(queueName, "functional_flagqueue") == 0) {
    if (functional_flagQueue != NULL) {
        xQueueOverwrite(functional_flagQueue, &newValues);
    }
}

}

//load struct overload function
bool CommandHandler::loadStruct(wifi_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("wifi",doc)){
    strcpy(structData.ssid, doc["data"]["ssid"]);
    strcpy(structData.password, doc["data"]["password"]);
    return true;
}
if(!internal && loadSettings("wifi",doc)){
    strcpy(structData.ssid, doc["data"]["ssid"]);
    strcpy(structData.password, doc["data"]["password"]);
    return true;
}
else if(!hasValue){
    strcpy(structData.ssid, setupDoc["wifi"]["default"][0]);
    strcpy(structData.password, setupDoc["wifi"]["default"][1]);
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="wifi";
    (*docResult)["data"]["ssid"]=structData.ssid;
    (*docResult)["data"]["password"]=structData.password;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(mqtt_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("mqtt",doc)){
    strcpy(structData.host, doc["data"]["host"]);
    structData.port = doc["data"]["port"];
    strcpy(structData.username, doc["data"]["username"]);
    strcpy(structData.password, doc["data"]["password"]);
    return true;
}
if(!internal && loadSettings("mqtt",doc)){
    strcpy(structData.host, doc["data"]["host"]);
    structData.port = doc["data"]["port"];
    strcpy(structData.username, doc["data"]["username"]);
    strcpy(structData.password, doc["data"]["password"]);
    return true;
}
else if(!hasValue){
    strcpy(structData.host, setupDoc["mqtt"]["default"][0]);
    structData.port = setupDoc["mqtt"]["default"][1];
    strcpy(structData.username, setupDoc["mqtt"]["default"][2]);
    strcpy(structData.password, setupDoc["mqtt"]["default"][3]);
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="mqtt";
    (*docResult)["data"]["host"]=structData.host;
    (*docResult)["data"]["port"]=structData.port;
    (*docResult)["data"]["username"]=structData.username;
    (*docResult)["data"]["password"]=structData.password;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(interval_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("interval",doc)){
    structData.get_data = doc["data"]["get_data"];
    structData.upload_data = doc["data"]["upload_data"];
    structData.standby = doc["data"]["standby"];
    structData.heartbeat = doc["data"]["heartbeat"];
    structData.backup_data = doc["data"]["backup_data"];
    structData.delete_data = doc["data"]["delete_data"];
    structData.wifireconnect = doc["data"]["wifireconnect"];
    structData.mqttreconnect = doc["data"]["mqttreconnect"];
    structData.radioreconnect = doc["data"]["radioreconnect"];
    return true;
}
if(!internal && loadSettings("interval",doc)){
    structData.get_data = doc["data"]["get_data"];
    structData.upload_data = doc["data"]["upload_data"];
    structData.standby = doc["data"]["standby"];
    structData.heartbeat = doc["data"]["heartbeat"];
    structData.backup_data = doc["data"]["backup_data"];
    structData.delete_data = doc["data"]["delete_data"];
    structData.wifireconnect = doc["data"]["wifireconnect"];
    structData.mqttreconnect = doc["data"]["mqttreconnect"];
    structData.radioreconnect = doc["data"]["radioreconnect"];
    return true;
}
else if(!hasValue){
    structData.get_data = setupDoc["interval"]["default"][0];
    structData.upload_data = setupDoc["interval"]["default"][1];
    structData.standby = setupDoc["interval"]["default"][2];
    structData.heartbeat = setupDoc["interval"]["default"][3];
    structData.backup_data = setupDoc["interval"]["default"][4];
    structData.delete_data = setupDoc["interval"]["default"][5];
    structData.wifireconnect = setupDoc["interval"]["default"][6];
    structData.mqttreconnect = setupDoc["interval"]["default"][7];
    structData.radioreconnect = setupDoc["interval"]["default"][8];
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="interval";
    (*docResult)["data"]["get_data"]=structData.get_data;
    (*docResult)["data"]["upload_data"]=structData.upload_data;
    (*docResult)["data"]["standby"]=structData.standby;
    (*docResult)["data"]["heartbeat"]=structData.heartbeat;
    (*docResult)["data"]["backup_data"]=structData.backup_data;
    (*docResult)["data"]["delete_data"]=structData.delete_data;
    (*docResult)["data"]["wifireconnect"]=structData.wifireconnect;
    (*docResult)["data"]["mqttreconnect"]=structData.mqttreconnect;
    (*docResult)["data"]["radioreconnect"]=structData.radioreconnect;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(utcoffset_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("utcoffset",doc)){
    structData.utcoffset = doc["data"]["utcoffset"];
    return true;
}
if(!internal && loadSettings("utcoffset",doc)){
    structData.utcoffset = doc["data"]["utcoffset"];
    return true;
}
else if(!hasValue){
    structData.utcoffset = setupDoc["utcoffset"]["default"][0];
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="utcoffset";
    (*docResult)["data"]["utcoffset"]=structData.utcoffset;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(last_epoch_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("last_epoch",doc)){
    structData.epoch = doc["data"]["epoch"];
    return true;
}
if(!internal && loadSettings("last_epoch",doc)){
    structData.epoch = doc["data"]["epoch"];
    return true;
}
else if(!hasValue){
    structData.epoch = setupDoc["last_epoch"]["default"][0];
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="last_epoch";
    (*docResult)["data"]["epoch"]=structData.epoch;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(key_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("key",doc)){
    structData.key = doc["data"]["key"];
    return true;
}
if(!internal && loadSettings("key",doc)){
    structData.key = doc["data"]["key"];
    return true;
}
else if(!hasValue){
    structData.key = setupDoc["key"]["default"][0];
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="key";
    (*docResult)["data"]["key"]=structData.key;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(use_key_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("use_key",doc)){
    structData.state = doc["data"]["state"];
    return true;
}
if(!internal && loadSettings("use_key",doc)){
    structData.state = doc["data"]["state"];
    return true;
}
else if(!hasValue){
    structData.state = setupDoc["use_key"]["default"][0];
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="use_key";
    (*docResult)["data"]["state"]=structData.state;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(sn_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("sn",doc)){
    structData.sn = doc["data"]["sn"];
    strcpy(structData.alias, doc["data"]["alias"]);
    return true;
}
if(!internal && loadSettings("sn",doc)){
    structData.sn = doc["data"]["sn"];
    strcpy(structData.alias, doc["data"]["alias"]);
    return true;
}
else if(!hasValue){
    structData.sn = setupDoc["sn"]["default"][0];
    strcpy(structData.alias, setupDoc["sn"]["default"][1]);
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="sn";
    (*docResult)["data"]["sn"]=structData.sn;
    (*docResult)["data"]["alias"]=structData.alias;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(otaurl_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("otaurl",doc)){
    strcpy(structData.otaurl, doc["data"]["otaurl"]);
    return true;
}
if(!internal && loadSettings("otaurl",doc)){
    strcpy(structData.otaurl, doc["data"]["otaurl"]);
    return true;
}
else if(!hasValue){
    strcpy(structData.otaurl, setupDoc["otaurl"]["default"][0]);
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="otaurl";
    (*docResult)["data"]["otaurl"]=structData.otaurl;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(api_ver1_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("api_ver1",doc)){
    strcpy(structData.method, doc["data"]["method"]);
    strcpy(structData.api, doc["data"]["api"]);
    return true;
}
if(!internal && loadSettings("api_ver1",doc)){
    strcpy(structData.method, doc["data"]["method"]);
    strcpy(structData.api, doc["data"]["api"]);
    return true;
}
else if(!hasValue){
    strcpy(structData.method, setupDoc["api_ver1"]["default"][0]);
    strcpy(structData.api, setupDoc["api_ver1"]["default"][1]);
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="api_ver1";
    (*docResult)["data"]["method"]=structData.method;
    (*docResult)["data"]["api"]=structData.api;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(api_ver2_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("api_ver2",doc)){
    strcpy(structData.username, doc["data"]["username"]);
    strcpy(structData.client_id, doc["data"]["client_id"]);
    strcpy(structData.client_secret, doc["data"]["client_secret"]);
    strcpy(structData.api_key, doc["data"]["api_key"]);
    return true;
}
if(!internal && loadSettings("api_ver2",doc)){
    strcpy(structData.username, doc["data"]["username"]);
    strcpy(structData.client_id, doc["data"]["client_id"]);
    strcpy(structData.client_secret, doc["data"]["client_secret"]);
    strcpy(structData.api_key, doc["data"]["api_key"]);
    return true;
}
else if(!hasValue){
    strcpy(structData.username, setupDoc["api_ver2"]["default"][0]);
    strcpy(structData.client_id, setupDoc["api_ver2"]["default"][1]);
    strcpy(structData.client_secret, setupDoc["api_ver2"]["default"][2]);
    strcpy(structData.api_key, setupDoc["api_ver2"]["default"][3]);
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="api_ver2";
    (*docResult)["data"]["username"]=structData.username;
    (*docResult)["data"]["client_id"]=structData.client_id;
    (*docResult)["data"]["client_secret"]=structData.client_secret;
    (*docResult)["data"]["api_key"]=structData.api_key;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(adv_ble_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("adv_ble",doc)){
    structData.state = doc["data"]["state"];
    return true;
}
if(!internal && loadSettings("adv_ble",doc)){
    structData.state = doc["data"]["state"];
    return true;
}
else if(!hasValue){
    structData.state = setupDoc["adv_ble"]["default"][0];
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="adv_ble";
    (*docResult)["data"]["state"]=structData.state;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(radio_mode_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("radio_mode",doc)){
    structData.channel = doc["data"]["channel"];
    structData.is_fsk = doc["data"]["is_fsk"];
    structData.gateway_id = doc["data"]["gateway_id"];
    structData.randomness = doc["data"]["randomness"];
    return true;
}
if(!internal && loadSettings("radio_mode",doc)){
    structData.channel = doc["data"]["channel"];
    structData.is_fsk = doc["data"]["is_fsk"];
    structData.gateway_id = doc["data"]["gateway_id"];
    structData.randomness = doc["data"]["randomness"];
    return true;
}
else if(!hasValue){
    structData.channel = setupDoc["radio_mode"]["default"][0];
    structData.is_fsk = setupDoc["radio_mode"]["default"][1];
    structData.gateway_id = setupDoc["radio_mode"]["default"][2];
    structData.randomness = setupDoc["radio_mode"]["default"][3];
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="radio_mode";
    (*docResult)["data"]["channel"]=structData.channel;
    (*docResult)["data"]["is_fsk"]=structData.is_fsk;
    (*docResult)["data"]["gateway_id"]=structData.gateway_id;
    (*docResult)["data"]["randomness"]=structData.randomness;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(radio_param_1_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("radio_param_1",doc)){
    structData.bandwidth = doc["data"]["bandwidth"];
    structData.tx = doc["data"]["tx"];
    structData.rx = doc["data"]["rx"];
    structData.cr = doc["data"]["cr"];
    structData.sf = doc["data"]["sf"];
    structData.db = doc["data"]["db"];
    structData.bitrate = doc["data"]["bitrate"];
    return true;
}
if(!internal && loadSettings("radio_param_1",doc)){
    structData.bandwidth = doc["data"]["bandwidth"];
    structData.tx = doc["data"]["tx"];
    structData.rx = doc["data"]["rx"];
    structData.cr = doc["data"]["cr"];
    structData.sf = doc["data"]["sf"];
    structData.db = doc["data"]["db"];
    structData.bitrate = doc["data"]["bitrate"];
    return true;
}
else if(!hasValue){
    structData.bandwidth = setupDoc["radio_param_1"]["default"][0];
    structData.tx = setupDoc["radio_param_1"]["default"][1];
    structData.rx = setupDoc["radio_param_1"]["default"][2];
    structData.cr = setupDoc["radio_param_1"]["default"][3];
    structData.sf = setupDoc["radio_param_1"]["default"][4];
    structData.db = setupDoc["radio_param_1"]["default"][5];
    structData.bitrate = setupDoc["radio_param_1"]["default"][6];
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="radio_param_1";
    (*docResult)["data"]["bandwidth"]=structData.bandwidth;
    (*docResult)["data"]["tx"]=structData.tx;
    (*docResult)["data"]["rx"]=structData.rx;
    (*docResult)["data"]["cr"]=structData.cr;
    (*docResult)["data"]["sf"]=structData.sf;
    (*docResult)["data"]["db"]=structData.db;
    (*docResult)["data"]["bitrate"]=structData.bitrate;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(radio_param_2_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("radio_param_2",doc)){
    structData.bandwidth = doc["data"]["bandwidth"];
    structData.tx = doc["data"]["tx"];
    structData.rx = doc["data"]["rx"];
    structData.cr = doc["data"]["cr"];
    structData.sf = doc["data"]["sf"];
    structData.db = doc["data"]["db"];
    structData.bitrate = doc["data"]["bitrate"];
    return true;
}
if(!internal && loadSettings("radio_param_2",doc)){
    structData.bandwidth = doc["data"]["bandwidth"];
    structData.tx = doc["data"]["tx"];
    structData.rx = doc["data"]["rx"];
    structData.cr = doc["data"]["cr"];
    structData.sf = doc["data"]["sf"];
    structData.db = doc["data"]["db"];
    structData.bitrate = doc["data"]["bitrate"];
    return true;
}
else if(!hasValue){
    structData.bandwidth = setupDoc["radio_param_2"]["default"][0];
    structData.tx = setupDoc["radio_param_2"]["default"][1];
    structData.rx = setupDoc["radio_param_2"]["default"][2];
    structData.cr = setupDoc["radio_param_2"]["default"][3];
    structData.sf = setupDoc["radio_param_2"]["default"][4];
    structData.db = setupDoc["radio_param_2"]["default"][5];
    structData.bitrate = setupDoc["radio_param_2"]["default"][6];
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="radio_param_2";
    (*docResult)["data"]["bandwidth"]=structData.bandwidth;
    (*docResult)["data"]["tx"]=structData.tx;
    (*docResult)["data"]["rx"]=structData.rx;
    (*docResult)["data"]["cr"]=structData.cr;
    (*docResult)["data"]["sf"]=structData.sf;
    (*docResult)["data"]["db"]=structData.db;
    (*docResult)["data"]["bitrate"]=structData.bitrate;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(radio_param_3_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("radio_param_3",doc)){
    structData.bandwidth = doc["data"]["bandwidth"];
    structData.tx = doc["data"]["tx"];
    structData.rx = doc["data"]["rx"];
    structData.cr = doc["data"]["cr"];
    structData.sf = doc["data"]["sf"];
    structData.db = doc["data"]["db"];
    structData.bitrate = doc["data"]["bitrate"];
    return true;
}
if(!internal && loadSettings("radio_param_3",doc)){
    structData.bandwidth = doc["data"]["bandwidth"];
    structData.tx = doc["data"]["tx"];
    structData.rx = doc["data"]["rx"];
    structData.cr = doc["data"]["cr"];
    structData.sf = doc["data"]["sf"];
    structData.db = doc["data"]["db"];
    structData.bitrate = doc["data"]["bitrate"];
    return true;
}
else if(!hasValue){
    structData.bandwidth = setupDoc["radio_param_3"]["default"][0];
    structData.tx = setupDoc["radio_param_3"]["default"][1];
    structData.rx = setupDoc["radio_param_3"]["default"][2];
    structData.cr = setupDoc["radio_param_3"]["default"][3];
    structData.sf = setupDoc["radio_param_3"]["default"][4];
    structData.db = setupDoc["radio_param_3"]["default"][5];
    structData.bitrate = setupDoc["radio_param_3"]["default"][6];
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="radio_param_3";
    (*docResult)["data"]["bandwidth"]=structData.bandwidth;
    (*docResult)["data"]["tx"]=structData.tx;
    (*docResult)["data"]["rx"]=structData.rx;
    (*docResult)["data"]["cr"]=structData.cr;
    (*docResult)["data"]["sf"]=structData.sf;
    (*docResult)["data"]["db"]=structData.db;
    (*docResult)["data"]["bitrate"]=structData.bitrate;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(radio_param_4_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("radio_param_4",doc)){
    structData.bandwidth = doc["data"]["bandwidth"];
    structData.tx = doc["data"]["tx"];
    structData.rx = doc["data"]["rx"];
    structData.cr = doc["data"]["cr"];
    structData.sf = doc["data"]["sf"];
    structData.db = doc["data"]["db"];
    structData.bitrate = doc["data"]["bitrate"];
    return true;
}
if(!internal && loadSettings("radio_param_4",doc)){
    structData.bandwidth = doc["data"]["bandwidth"];
    structData.tx = doc["data"]["tx"];
    structData.rx = doc["data"]["rx"];
    structData.cr = doc["data"]["cr"];
    structData.sf = doc["data"]["sf"];
    structData.db = doc["data"]["db"];
    structData.bitrate = doc["data"]["bitrate"];
    return true;
}
else if(!hasValue){
    structData.bandwidth = setupDoc["radio_param_4"]["default"][0];
    structData.tx = setupDoc["radio_param_4"]["default"][1];
    structData.rx = setupDoc["radio_param_4"]["default"][2];
    structData.cr = setupDoc["radio_param_4"]["default"][3];
    structData.sf = setupDoc["radio_param_4"]["default"][4];
    structData.db = setupDoc["radio_param_4"]["default"][5];
    structData.bitrate = setupDoc["radio_param_4"]["default"][6];
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="radio_param_4";
    (*docResult)["data"]["bandwidth"]=structData.bandwidth;
    (*docResult)["data"]["tx"]=structData.tx;
    (*docResult)["data"]["rx"]=structData.rx;
    (*docResult)["data"]["cr"]=structData.cr;
    (*docResult)["data"]["sf"]=structData.sf;
    (*docResult)["data"]["db"]=structData.db;
    (*docResult)["data"]["bitrate"]=structData.bitrate;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(license_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("license",doc)){
    strcpy(structData.license, doc["data"]["license"]);
    return true;
}
if(!internal && loadSettings("license",doc)){
    strcpy(structData.license, doc["data"]["license"]);
    return true;
}
else if(!hasValue){
    strcpy(structData.license, setupDoc["license"]["default"][0]);
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="license";
    (*docResult)["data"]["license"]=structData.license;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(suspend_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("suspend",doc)){
    structData.state = doc["data"]["state"];
    return true;
}
if(!internal && loadSettings("suspend",doc)){
    structData.state = doc["data"]["state"];
    return true;
}
else if(!hasValue){
    structData.state = setupDoc["suspend"]["default"][0];
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="suspend";
    (*docResult)["data"]["state"]=structData.state;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(hierarchy_setup_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("hierarchy_setup",doc)){
    strcpy(structData.pt, doc["data"]["pt"]);
    strcpy(structData.unit, doc["data"]["unit"]);
    strcpy(structData.divisi, doc["data"]["divisi"]);
    return true;
}
if(!internal && loadSettings("hierarchy_setup",doc)){
    strcpy(structData.pt, doc["data"]["pt"]);
    strcpy(structData.unit, doc["data"]["unit"]);
    strcpy(structData.divisi, doc["data"]["divisi"]);
    return true;
}
else if(!hasValue){
    strcpy(structData.pt, setupDoc["hierarchy_setup"]["default"][0]);
    strcpy(structData.unit, setupDoc["hierarchy_setup"]["default"][1]);
    strcpy(structData.divisi, setupDoc["hierarchy_setup"]["default"][2]);
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="hierarchy_setup";
    (*docResult)["data"]["pt"]=structData.pt;
    (*docResult)["data"]["unit"]=structData.unit;
    (*docResult)["data"]["divisi"]=structData.divisi;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(fingerprint_setup_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("fingerprint_setup",doc)){
    structData.security_level = doc["data"]["security_level"];
    structData.flag_absen = doc["data"]["flag_absen"];
    structData.gps_validation = doc["data"]["gps_validation"];
    structData.geofencing = doc["data"]["geofencing"];
    structData.geofencing_lat = doc["data"]["geofencing_lat"];
    structData.geofencing_lng = doc["data"]["geofencing_lng"];
    structData.geofencing_radius = doc["data"]["geofencing_radius"];
    structData.scan_mode = doc["data"]["scan_mode"];
    structData.operation_mode = doc["data"]["operation_mode"];
    return true;
}
if(!internal && loadSettings("fingerprint_setup",doc)){
    structData.security_level = doc["data"]["security_level"];
    structData.flag_absen = doc["data"]["flag_absen"];
    structData.gps_validation = doc["data"]["gps_validation"];
    structData.geofencing = doc["data"]["geofencing"];
    structData.geofencing_lat = doc["data"]["geofencing_lat"];
    structData.geofencing_lng = doc["data"]["geofencing_lng"];
    structData.geofencing_radius = doc["data"]["geofencing_radius"];
    structData.scan_mode = doc["data"]["scan_mode"];
    structData.operation_mode = doc["data"]["operation_mode"];
    return true;
}
else if(!hasValue){
    structData.security_level = setupDoc["fingerprint_setup"]["default"][0];
    structData.flag_absen = setupDoc["fingerprint_setup"]["default"][1];
    structData.gps_validation = setupDoc["fingerprint_setup"]["default"][2];
    structData.geofencing = setupDoc["fingerprint_setup"]["default"][3];
    structData.geofencing_lat = setupDoc["fingerprint_setup"]["default"][4];
    structData.geofencing_lng = setupDoc["fingerprint_setup"]["default"][5];
    structData.geofencing_radius = setupDoc["fingerprint_setup"]["default"][6];
    structData.scan_mode = setupDoc["fingerprint_setup"]["default"][7];
    structData.operation_mode = setupDoc["fingerprint_setup"]["default"][8];
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="fingerprint_setup";
    (*docResult)["data"]["security_level"]=structData.security_level;
    (*docResult)["data"]["flag_absen"]=structData.flag_absen;
    (*docResult)["data"]["gps_validation"]=structData.gps_validation;
    (*docResult)["data"]["geofencing"]=structData.geofencing;
    (*docResult)["data"]["geofencing_lat"]=structData.geofencing_lat;
    (*docResult)["data"]["geofencing_lng"]=structData.geofencing_lng;
    (*docResult)["data"]["geofencing_radius"]=structData.geofencing_radius;
    (*docResult)["data"]["scan_mode"]=structData.scan_mode;
    (*docResult)["data"]["operation_mode"]=structData.operation_mode;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(stb_bandul_setup_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("stb_bandul_setup",doc)){
    structData.bandul_id = doc["data"]["bandul_id"];
    structData.bandul_length = doc["data"]["bandul_length"];
    return true;
}
if(!internal && loadSettings("stb_bandul_setup",doc)){
    structData.bandul_id = doc["data"]["bandul_id"];
    structData.bandul_length = doc["data"]["bandul_length"];
    return true;
}
else if(!hasValue){
    structData.bandul_id = setupDoc["stb_bandul_setup"]["default"][0];
    structData.bandul_length = setupDoc["stb_bandul_setup"]["default"][1];
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="stb_bandul_setup";
    (*docResult)["data"]["bandul_id"]=structData.bandul_id;
    (*docResult)["data"]["bandul_length"]=structData.bandul_length;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(pom_setup_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("pom_setup",doc)){
    structData.konstanta = doc["data"]["konstanta"];
    structData.validasi = doc["data"]["validasi"];
    structData.stock = doc["data"]["stock"];
    structData.max_stock = doc["data"]["max_stock"];
    structData.min_stock = doc["data"]["min_stock"];
    return true;
}
if(!internal && loadSettings("pom_setup",doc)){
    structData.konstanta = doc["data"]["konstanta"];
    structData.validasi = doc["data"]["validasi"];
    structData.stock = doc["data"]["stock"];
    structData.max_stock = doc["data"]["max_stock"];
    structData.min_stock = doc["data"]["min_stock"];
    return true;
}
else if(!hasValue){
    structData.konstanta = setupDoc["pom_setup"]["default"][0];
    structData.validasi = setupDoc["pom_setup"]["default"][1];
    structData.stock = setupDoc["pom_setup"]["default"][2];
    structData.max_stock = setupDoc["pom_setup"]["default"][3];
    structData.min_stock = setupDoc["pom_setup"]["default"][4];
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="pom_setup";
    (*docResult)["data"]["konstanta"]=structData.konstanta;
    (*docResult)["data"]["validasi"]=structData.validasi;
    (*docResult)["data"]["stock"]=structData.stock;
    (*docResult)["data"]["max_stock"]=structData.max_stock;
    (*docResult)["data"]["min_stock"]=structData.min_stock;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(stb_controller_setup_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("stb_controller_setup",doc)){
    structData.offset = doc["data"]["offset"];
    structData.mejaukur = doc["data"]["mejaukur"];
    structData.crosscek = doc["data"]["crosscek"];
    structData.filter_minyak_dari_bawah = doc["data"]["filter_minyak_dari_bawah"];
    structData.filter_minyak_dari_atas = doc["data"]["filter_minyak_dari_atas"];
    structData.filter_gulungan_habis = doc["data"]["filter_gulungan_habis"];
    structData.ignore = doc["data"]["ignore"];
    structData.speed_naik = doc["data"]["speed_naik"];
    structData.speed_turun = doc["data"]["speed_turun"];
    structData.timeout = doc["data"]["timeout"];
    structData.interval_cek_air = doc["data"]["interval_cek_air"];
    structData.loop_cek_air = doc["data"]["loop_cek_air"];
    structData.jarak_cek_air = doc["data"]["jarak_cek_air"];
    structData.jarak_bersih = doc["data"]["jarak_bersih"];
    structData.loop_bersih = doc["data"]["loop_bersih"];
    structData.validasi_deteksi = doc["data"]["validasi_deteksi"];
    structData.tinggi_meja = doc["data"]["tinggi_meja"];
    return true;
}
if(!internal && loadSettings("stb_controller_setup",doc)){
    structData.offset = doc["data"]["offset"];
    structData.mejaukur = doc["data"]["mejaukur"];
    structData.crosscek = doc["data"]["crosscek"];
    structData.filter_minyak_dari_bawah = doc["data"]["filter_minyak_dari_bawah"];
    structData.filter_minyak_dari_atas = doc["data"]["filter_minyak_dari_atas"];
    structData.filter_gulungan_habis = doc["data"]["filter_gulungan_habis"];
    structData.ignore = doc["data"]["ignore"];
    structData.speed_naik = doc["data"]["speed_naik"];
    structData.speed_turun = doc["data"]["speed_turun"];
    structData.timeout = doc["data"]["timeout"];
    structData.interval_cek_air = doc["data"]["interval_cek_air"];
    structData.loop_cek_air = doc["data"]["loop_cek_air"];
    structData.jarak_cek_air = doc["data"]["jarak_cek_air"];
    structData.jarak_bersih = doc["data"]["jarak_bersih"];
    structData.loop_bersih = doc["data"]["loop_bersih"];
    structData.validasi_deteksi = doc["data"]["validasi_deteksi"];
    structData.tinggi_meja = doc["data"]["tinggi_meja"];
    return true;
}
else if(!hasValue){
    structData.offset = setupDoc["stb_controller_setup"]["default"][0];
    structData.mejaukur = setupDoc["stb_controller_setup"]["default"][1];
    structData.crosscek = setupDoc["stb_controller_setup"]["default"][2];
    structData.filter_minyak_dari_bawah = setupDoc["stb_controller_setup"]["default"][3];
    structData.filter_minyak_dari_atas = setupDoc["stb_controller_setup"]["default"][4];
    structData.filter_gulungan_habis = setupDoc["stb_controller_setup"]["default"][5];
    structData.ignore = setupDoc["stb_controller_setup"]["default"][6];
    structData.speed_naik = setupDoc["stb_controller_setup"]["default"][7];
    structData.speed_turun = setupDoc["stb_controller_setup"]["default"][8];
    structData.timeout = setupDoc["stb_controller_setup"]["default"][9];
    structData.interval_cek_air = setupDoc["stb_controller_setup"]["default"][10];
    structData.loop_cek_air = setupDoc["stb_controller_setup"]["default"][11];
    structData.jarak_cek_air = setupDoc["stb_controller_setup"]["default"][12];
    structData.jarak_bersih = setupDoc["stb_controller_setup"]["default"][13];
    structData.loop_bersih = setupDoc["stb_controller_setup"]["default"][14];
    structData.validasi_deteksi = setupDoc["stb_controller_setup"]["default"][15];
    structData.tinggi_meja = setupDoc["stb_controller_setup"]["default"][16];
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="stb_controller_setup";
    (*docResult)["data"]["offset"]=structData.offset;
    (*docResult)["data"]["mejaukur"]=structData.mejaukur;
    (*docResult)["data"]["crosscek"]=structData.crosscek;
    (*docResult)["data"]["filter_minyak_dari_bawah"]=structData.filter_minyak_dari_bawah;
    (*docResult)["data"]["filter_minyak_dari_atas"]=structData.filter_minyak_dari_atas;
    (*docResult)["data"]["filter_gulungan_habis"]=structData.filter_gulungan_habis;
    (*docResult)["data"]["ignore"]=structData.ignore;
    (*docResult)["data"]["speed_naik"]=structData.speed_naik;
    (*docResult)["data"]["speed_turun"]=structData.speed_turun;
    (*docResult)["data"]["timeout"]=structData.timeout;
    (*docResult)["data"]["interval_cek_air"]=structData.interval_cek_air;
    (*docResult)["data"]["loop_cek_air"]=structData.loop_cek_air;
    (*docResult)["data"]["jarak_cek_air"]=structData.jarak_cek_air;
    (*docResult)["data"]["jarak_bersih"]=structData.jarak_bersih;
    (*docResult)["data"]["loop_bersih"]=structData.loop_bersih;
    (*docResult)["data"]["validasi_deteksi"]=structData.validasi_deteksi;
    (*docResult)["data"]["tinggi_meja"]=structData.tinggi_meja;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(stb_mekanikal_setup_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("stb_mekanikal_setup",doc)){
    structData.mekanikal_id = doc["data"]["mekanikal_id"];
    structData.maxrange = doc["data"]["maxrange"];
    structData.opto_timeout_naik = doc["data"]["opto_timeout_naik"];
    structData.pwm_off = doc["data"]["pwm_off"];
    structData.limit_switch = doc["data"]["limit_switch"];
    structData.pressure_switch = doc["data"]["pressure_switch"];
    structData.pwm_resolution = doc["data"]["pwm_resolution"];
    return true;
}
if(!internal && loadSettings("stb_mekanikal_setup",doc)){
    structData.mekanikal_id = doc["data"]["mekanikal_id"];
    structData.maxrange = doc["data"]["maxrange"];
    structData.opto_timeout_naik = doc["data"]["opto_timeout_naik"];
    structData.pwm_off = doc["data"]["pwm_off"];
    structData.limit_switch = doc["data"]["limit_switch"];
    structData.pressure_switch = doc["data"]["pressure_switch"];
    structData.pwm_resolution = doc["data"]["pwm_resolution"];
    return true;
}
else if(!hasValue){
    structData.mekanikal_id = setupDoc["stb_mekanikal_setup"]["default"][0];
    structData.maxrange = setupDoc["stb_mekanikal_setup"]["default"][1];
    structData.opto_timeout_naik = setupDoc["stb_mekanikal_setup"]["default"][2];
    structData.pwm_off = setupDoc["stb_mekanikal_setup"]["default"][3];
    structData.limit_switch = setupDoc["stb_mekanikal_setup"]["default"][4];
    structData.pressure_switch = setupDoc["stb_mekanikal_setup"]["default"][5];
    structData.pwm_resolution = setupDoc["stb_mekanikal_setup"]["default"][6];
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="stb_mekanikal_setup";
    (*docResult)["data"]["mekanikal_id"]=structData.mekanikal_id;
    (*docResult)["data"]["maxrange"]=structData.maxrange;
    (*docResult)["data"]["opto_timeout_naik"]=structData.opto_timeout_naik;
    (*docResult)["data"]["pwm_off"]=structData.pwm_off;
    (*docResult)["data"]["limit_switch"]=structData.limit_switch;
    (*docResult)["data"]["pressure_switch"]=structData.pressure_switch;
    (*docResult)["data"]["pwm_resolution"]=structData.pwm_resolution;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(tracker_setup_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("tracker_setup",doc)){
    strcpy(structData.karyawan_name, doc["data"]["karyawan_name"]);
    structData.activity_id = doc["data"]["activity_id"];
    structData.latitude = doc["data"]["latitude"];
    structData.longitude = doc["data"]["longitude"];
    structData.radius = doc["data"]["radius"];
    structData.geofence = doc["data"]["geofence"];
    structData.com_mode = doc["data"]["com_mode"];
    return true;
}
if(!internal && loadSettings("tracker_setup",doc)){
    strcpy(structData.karyawan_name, doc["data"]["karyawan_name"]);
    structData.activity_id = doc["data"]["activity_id"];
    structData.latitude = doc["data"]["latitude"];
    structData.longitude = doc["data"]["longitude"];
    structData.radius = doc["data"]["radius"];
    structData.geofence = doc["data"]["geofence"];
    structData.com_mode = doc["data"]["com_mode"];
    return true;
}
else if(!hasValue){
    strcpy(structData.karyawan_name, setupDoc["tracker_setup"]["default"][0]);
    structData.activity_id = setupDoc["tracker_setup"]["default"][1];
    structData.latitude = setupDoc["tracker_setup"]["default"][2];
    structData.longitude = setupDoc["tracker_setup"]["default"][3];
    structData.radius = setupDoc["tracker_setup"]["default"][4];
    structData.geofence = setupDoc["tracker_setup"]["default"][5];
    structData.com_mode = setupDoc["tracker_setup"]["default"][6];
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="tracker_setup";
    (*docResult)["data"]["karyawan_name"]=structData.karyawan_name;
    (*docResult)["data"]["activity_id"]=structData.activity_id;
    (*docResult)["data"]["latitude"]=structData.latitude;
    (*docResult)["data"]["longitude"]=structData.longitude;
    (*docResult)["data"]["radius"]=structData.radius;
    (*docResult)["data"]["geofence"]=structData.geofence;
    (*docResult)["data"]["com_mode"]=structData.com_mode;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(stb_controller_sub_setup_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("stb_controller_sub_setup",doc)){
    structData.interval_air = doc["data"]["interval_air"];
    structData.loop_air = doc["data"]["loop_air"];
    structData.loop_bersih = doc["data"]["loop_bersih"];
    structData.jarak_bersih = doc["data"]["jarak_bersih"];
    structData.validate_detection = doc["data"]["validate_detection"];
    return true;
}
if(!internal && loadSettings("stb_controller_sub_setup",doc)){
    structData.interval_air = doc["data"]["interval_air"];
    structData.loop_air = doc["data"]["loop_air"];
    structData.loop_bersih = doc["data"]["loop_bersih"];
    structData.jarak_bersih = doc["data"]["jarak_bersih"];
    structData.validate_detection = doc["data"]["validate_detection"];
    return true;
}
else if(!hasValue){
    structData.interval_air = setupDoc["stb_controller_sub_setup"]["default"][0];
    structData.loop_air = setupDoc["stb_controller_sub_setup"]["default"][1];
    structData.loop_bersih = setupDoc["stb_controller_sub_setup"]["default"][2];
    structData.jarak_bersih = setupDoc["stb_controller_sub_setup"]["default"][3];
    structData.validate_detection = setupDoc["stb_controller_sub_setup"]["default"][4];
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="stb_controller_sub_setup";
    (*docResult)["data"]["interval_air"]=structData.interval_air;
    (*docResult)["data"]["loop_air"]=structData.loop_air;
    (*docResult)["data"]["loop_bersih"]=structData.loop_bersih;
    (*docResult)["data"]["jarak_bersih"]=structData.jarak_bersih;
    (*docResult)["data"]["validate_detection"]=structData.validate_detection;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(esp_now_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("esp_now",doc)){
    structData.channel = doc["data"]["channel"];
    structData.longrange = doc["data"]["longrange"];
    return true;
}
if(!internal && loadSettings("esp_now",doc)){
    structData.channel = doc["data"]["channel"];
    structData.longrange = doc["data"]["longrange"];
    return true;
}
else if(!hasValue){
    structData.channel = setupDoc["esp_now"]["default"][0];
    structData.longrange = setupDoc["esp_now"]["default"][1];
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="esp_now";
    (*docResult)["data"]["channel"]=structData.channel;
    (*docResult)["data"]["longrange"]=structData.longrange;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(functional_flag_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("functional_flag",doc)){
    structData.ble_state = doc["data"]["ble_state"];
    structData.mqtt_state = doc["data"]["mqtt_state"];
    structData.radio_state = doc["data"]["radio_state"];
    structData.schedule_state = doc["data"]["schedule_state"];
    structData.gps_state = doc["data"]["gps_state"];
    structData.espnow_state = doc["data"]["espnow_state"];
    return true;
}
if(!internal && loadSettings("functional_flag",doc)){
    structData.ble_state = doc["data"]["ble_state"];
    structData.mqtt_state = doc["data"]["mqtt_state"];
    structData.radio_state = doc["data"]["radio_state"];
    structData.schedule_state = doc["data"]["schedule_state"];
    structData.gps_state = doc["data"]["gps_state"];
    structData.espnow_state = doc["data"]["espnow_state"];
    return true;
}
else if(!hasValue){
    structData.ble_state = setupDoc["functional_flag"]["default"][0];
    structData.mqtt_state = setupDoc["functional_flag"]["default"][1];
    structData.radio_state = setupDoc["functional_flag"]["default"][2];
    structData.schedule_state = setupDoc["functional_flag"]["default"][3];
    structData.gps_state = setupDoc["functional_flag"]["default"][4];
    structData.espnow_state = setupDoc["functional_flag"]["default"][5];
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="functional_flag";
    (*docResult)["data"]["ble_state"]=structData.ble_state;
    (*docResult)["data"]["mqtt_state"]=structData.mqtt_state;
    (*docResult)["data"]["radio_state"]=structData.radio_state;
    (*docResult)["data"]["schedule_state"]=structData.schedule_state;
    (*docResult)["data"]["gps_state"]=structData.gps_state;
    (*docResult)["data"]["espnow_state"]=structData.espnow_state;
    return false;}


  return false;
}


