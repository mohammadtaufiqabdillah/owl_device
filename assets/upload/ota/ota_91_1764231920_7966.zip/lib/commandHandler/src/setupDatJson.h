const char* setupDatJson=R"(
{
    "pom_data": {
        "commandId": "1",
        "key": [
            "transaksi_id",
            "liter",
            "plat",
            "karyawan_id",
            "stock",
            "date"
        ],
        "data_type": [
            "uint32_t",
            "float",
            "string",
            "uint32_t",
            "float",
            "string"
        ],
        "data_len": [
            4,
            4,
            15,
            4,
            4,
            23
        ],
        "path": "/pom_data"
    },
    "radio_pooling_data": {
        "commandId": "2",
        "key": [
            "repeater_number",
            "repeater_1",
            "repeater_2",
            "repeater_3",
            "repeater_4",
            "repeater_5"
        ],
        "data_type": [
            "uint8_t",
            "uint32_t",
            "uint32_t",
            "uint32_t",
            "uint32_t",
            "uint32_t"
        ],
        "data_len": [
            1,
            4,
            4,
            4,
            4,
            4
        ],
        "path": "/radio_pooling_data"
    },
    "bandul_data": {
        "commandId": "3",
        "key": [
            "baterai",
            "count",
            "min_temp_bandul",
            "avg_temp_bandul",
            "max_temp_bandul",
            "avg_temp_probe",
            "air",
            "lumpur",
            "sync"
        ],
        "data_type": [
            "int8_t",
            "uint32_t",
            "float",
            "float",
            "float",
            "float",
            "float",
            "float",
            "uint32_t"
        ],
        "data_len": [
            1,
            4,
            4,
            4,
            4,
            4,
            4,
            4,
            4
        ],
        "path": "/bandul_data"
    },
    "logger_gps_data": {
        "commandId": "4",
        "key": [
            "activity_id",
            "battery",
            "latitude",
            "recorded_at"
        ],
        "data_type": [
            "uint32_t",
            "uint8_t",
            "float",
            "uint32_t"
        ],
        "data_len": [
            4,
            1,
            4,
            4
        ],
        "path": "/logger_gps_data"
    },
    "logger_vehicle_gps_data": {
        "commandId": "6",
        "key": [
            "karyawan_id",
            "activity_id",
            "latitude",
            "longitude",
            "altitude",
            "speed",
            "maxspeed",
            "trip",
            "fuel",
            "recorded_at"
        ],
        "data_type": [
            "uint32_t",
            "uint32_t",
            "float",
            "float",
            "float",
            "float",
            "float",
            "float",
            "float",
            "uint32_t"
        ],
        "data_len": [
            4,
            4,
            4,
            4,
            4,
            4,
            4,
            4,
            4,
            4
        ],
        "path": "/logger_vehicle_gps_data"
    },
    "radio_broadcast_data": {
        "commandId": "7",
        "key": [
            "unix_time",
            "interval_broadcast",
            "channel"
        ],
        "data_type": [
            "uint32_t",
            "uint8_t",
            "uint8_t"
        ],
        "data_len": [
            4,
            1,
            1
        ],
        "path": "/radio_broadcast_data"
    },
    "radio_join_data": {
        "commandId": "8",
        "key": [
            "state"
        ],
        "data_type": [
            "bool"
        ],
        "data_len": [
            1
        ],
        "path": "/radio_join_data"
    },
    "radio_response_data": {
        "commandId": "9",
        "key": [
            "status",
            "status_code"
        ],
        "data_type": [
            "bool",
            "uint32_t"
        ],
        "data_len": [
            1,
            4
        ],
        "path": "/radio_response_data"
    },
    "stb_notification": {
        "commandId": "10",
        "key": [
            "status",
            "status_error",
            "step",
            "description",
            "unix",
            "jarak"
        ],
        "data_type": [
            "string",
            "uint32_t",
            "string",
            "string",
            "uint32_t",
            "float"
        ],
        "data_len": [
            10,
            4,
            20,
            100,
            4,
            4
        ],
        "path": "/stb_notification"
    },
    "stb_sounding_data": {
        "commandId": "11",
        "key": [
            "tinggi_minyak_dari_atas",
            "tinggi_minyak_dari_bawah",
            "tinggi_udara_dari_atas",
            "tinggi_udara_dari_bawah",
            "suhu",
            "baterai_bandul",
            "status",
            "error_code",
            "average_1",
            "average_2",
            "speed_naik",
            "speed_turun",
            "mejaukur",
            "minyak",
            "air",
            "lumpur",
            "tinggi_meja",
            "deviasi",
            "v_charge",
            "suhu_rtc",
            "suhu_bandul",
            "suhu_probe",
            "suhu_mek",
            "recorded_at"
        ],
        "data_type": [
            "float",
            "float",
            "float",
            "float",
            "float",
            "float",
            "bool",
            "uint32_t",
            "float",
            "float",
            "int16_t",
            "int16_t",
            "float",
            "float",
            "float",
            "float",
            "float",
            "float",
            "float",
            "float",
            "float",
            "float",
            "float",
            "uint32_t"
        ],
        "data_len": [
            4,
            4,
            4,
            4,
            4,
            4,
            1,
            4,
            4,
            4,
            2,
            2,
            4,
            4,
            4,
            4,
            4,
            4,
            4,
            4,
            4,
            4,
            4,
            4
        ],
        "path": "/stb_sounding_data"
    },
    "soil_data": {
        "commandId": "12",
        "key": [
            "recorded_at"
        ],
        "data_type": [
            "string"
        ],
        "data_len": [
            20
        ],
        "path": "/soil_data"
    },
    "stb_data_air": {
        "commandId": "13",
        "key": [
            "air",
            "lumpur",
            "baterai_bandul",
            "suhu",
            "tinggi_air_lumpur"
        ],
        "data_type": [
            "float",
            "float",
            "float",
            "float",
            "float"
        ],
        "data_len": [
            4,
            4,
            4,
            4,
            4
        ],
        "path": "/stb_data_air"
    }
}
)";