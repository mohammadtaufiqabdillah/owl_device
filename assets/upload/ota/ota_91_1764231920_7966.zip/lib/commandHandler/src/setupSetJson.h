const char* setupSetJson=R"(
{
    "wifi": {
        "commandId": "1",
        "key": [
            "ssid",
            "password"
        ],
        "data_type": [
            "string",
            "string"
        ],
        "data_len": [
            25,
            25
        ],
        "default": [
            "Devices",
            "87654321"
        ],
        "queue": "wifiqueue",
        "path": "/wifi"
    },
    "mqtt": {
        "commandId": "2",
        "key": [
            "host",
            "port",
            "username",
            "password"
        ],
        "data_type": [
            "string",
            "uint16_t",
            "string",
            "string"
        ],
        "data_len": [
            125,
            2,
            25,
            25
        ],
        "default": [
            "8.215.79.132",
            1883,
            "user_mqtt",
            "Pa55w0rd"
        ],
        "queue": "mqttqueue",
        "path": "/mqtt"
    },
    "interval": {
        "commandId": "3",
        "key": [
            "get_data",
            "upload_data",
            "standby",
            "heartbeat",
            "backup_data",
            "delete_data",
            "wifireconnect",
            "mqttreconnect",
            "radioreconnect"
        ],
        "data_type": [
            "uint32_t",
            "uint32_t",
            "uint32_t",
            "uint32_t",
            "uint32_t",
            "uint32_t",
            "uint32_t",
            "uint32_t",
            "uint32_t"
        ],
        "data_len": [
            4,
            4,
            4,
            4,
            4,
            4,
            4,
            4,
            4
        ],
        "default": [
            60,
            600,
            60,
            60,
            600,
            360000,
            60,
            60,
            600
        ],
        "queue": "intervalqueue",
        "path": "/interval"
    },
    "utcoffset": {
        "commandId": "4",
        "key": [
            "utcoffset"
        ],
        "data_type": [
            "uint32_t"
        ],
        "data_len": [
            4
        ],
        "default": [
            7
        ],
        "queue": "utcoffsetqueue",
        "path": "/utcoffset"
    },
    "last_epoch": {
        "commandId": "5",
        "key": [
            "epoch"
        ],
        "data_type": [
            "uint32_t"
        ],
        "data_len": [
            4
        ],
        "default": [
            1000
        ],
        "queue": "last_epochqueue",
        "path": "/last_epoch"
    },
    "key": {
        "commandId": "6",
        "key": [
            "key"
        ],
        "data_type": [
            "uint16_t"
        ],
        "data_len": [
            2
        ],
        "default": [
            65535
        ],
        "queue": "keyqueue",
        "path": "/key"
    },
    "use_key": {
        "commandId": "7",
        "key": [
            "state"
        ],
        "data_type": [
            "bool"
        ],
        "data_len": [
            1
        ],
        "default": [
            false
        ],
        "queue": "use_keyqueue",
        "path": "/use_key"
    },
    "sn": {
        "commandId": "8",
        "key": [
            "sn",
            "alias"
        ],
        "data_type": [
            "uint32_t",
            "string"
        ],
        "data_len": [
            4,
            15
        ],
        "default": [
            99999,
            "FP11129"
        ],
        "queue": "snqueue",
        "path": "/sn"
    },
    "otaurl": {
        "commandId": "9",
        "key": [
            "otaurl"
        ],
        "data_type": [
            "string"
        ],
        "data_len": [
            125
        ],
        "default": [
            "http://103.150.191.136/owl_inventory/produksi/firmware.php"
        ],
        "queue": "otaurlqueue",
        "path": "/otaurl"
    },
    "api_ver1": {
        "commandId": "10",
        "key": [
            "method",
            "api"
        ],
        "data_type": [
            "string",
            "string"
        ],
        "data_len": [
            150,
            200
        ],
        "default": [
            "https://owlfork.co.id/iot.php/api/access_token/api_key",
            "https://owlfork.co.id/iot.php/api/module/device/register/send"
        ],
        "queue": "api_ver1queue",
        "path": "/api_ver1"
    },
    "api_ver2": {
        "commandId": "11",
        "key": [
            "username",
            "client_id",
            "client_secret",
            "api_key"
        ],
        "data_type": [
            "string",
            "string",
            "string",
            "string"
        ],
        "data_len": [
            30,
            40,
            100,
            100
        ],
        "default": [
            "deviceowl",
            "owl_internal",
            "qc_device_register",
            "rh23feafyq34ewff1fdahyw"
        ],
        "queue": "api_ver2queue",
        "path": "/api_ver2"
    },
    "adv_ble": {
        "commandId": "12",
        "key": [
            "state"
        ],
        "data_type": [
            "bool"
        ],
        "data_len": [
            1
        ],
        "default": [
            true
        ],
        "queue": "adv_blequeue",
        "path": "/adv_ble"
    },
    "radio_mode": {
        "commandId": "13",
        "key": [
            "channel",
            "is_fsk",
            "gateway_id",
            "randomness"
        ],
        "data_type": [
            "uint8_t",
            "bool",
            "uint32_t",
            "uint16_t"
        ],
        "data_len": [
            1,
            1,
            4,
            2
        ],
        "default": [
            1,
            false,
            0,
            50
        ],
        "queue": "radio_modequeue",
        "path": "/radio_mode"
    },
    "radio_param_1": {
        "commandId": "14",
        "key": [
            "bandwidth",
            "tx",
            "rx",
            "cr",
            "sf",
            "db",
            "bitrate"
        ],
        "data_type": [
            "float",
            "float",
            "float",
            "uint8_t",
            "uint8_t",
            "uint8_t",
            "float"
        ],
        "data_len": [
            4,
            4,
            4,
            1,
            1,
            1,
            4
        ],
        "default": [
            125,
            915,
            915.25,
            6,
            9,
            22,
            200
        ],
        "queue": "radio_param_1queue",
        "path": "/radio_param_1"
    },
    "radio_param_2": {
        "commandId": "15",
        "key": [
            "bandwidth",
            "tx",
            "rx",
            "cr",
            "sf",
            "db",
            "bitrate"
        ],
        "data_type": [
            "float",
            "float",
            "float",
            "uint8_t",
            "uint8_t",
            "uint8_t",
            "float"
        ],
        "data_len": [
            4,
            4,
            4,
            1,
            1,
            1,
            4
        ],
        "default": [
            125,
            915.5,
            915.75,
            6,
            9,
            22,
            200
        ],
        "queue": "radio_param_2queue",
        "path": "/radio_param_2"
    },
    "radio_param_3": {
        "commandId": "16",
        "key": [
            "bandwidth",
            "tx",
            "rx",
            "cr",
            "sf",
            "db",
            "bitrate"
        ],
        "data_type": [
            "float",
            "float",
            "float",
            "uint8_t",
            "uint8_t",
            "uint8_t",
            "float"
        ],
        "data_len": [
            4,
            4,
            4,
            1,
            1,
            1,
            4
        ],
        "default": [
            125,
            916,
            916.25,
            6,
            9,
            22,
            200
        ],
        "queue": "radio_param_3queue",
        "path": "/radio_param_3"
    },
    "radio_param_4": {
        "commandId": "17",
        "key": [
            "bandwidth",
            "tx",
            "rx",
            "cr",
            "sf",
            "db",
            "bitrate"
        ],
        "data_type": [
            "float",
            "float",
            "float",
            "uint8_t",
            "uint8_t",
            "uint8_t",
            "float"
        ],
        "data_len": [
            4,
            4,
            4,
            1,
            1,
            1,
            4
        ],
        "default": [
            125,
            916.5,
            916.75,
            6,
            9,
            22,
            200
        ],
        "queue": "radio_param_4queue",
        "path": "/radio_param_4"
    },
    "license": {
        "commandId": "18",
        "key": [
            "license"
        ],
        "data_type": [
            "string"
        ],
        "data_len": [
            80
        ],
        "default": [
            "aaiu78198fh2iuhf98yy389h"
        ],
        "queue": "licensequeue",
        "path": "/license"
    },
    "suspend": {
        "commandId": "19",
        "key": [
            "state"
        ],
        "data_type": [
            "bool"
        ],
        "data_len": [
            1
        ],
        "default": [
            false
        ],
        "queue": "suspendqueue",
        "path": "/suspend"
    },
    "hierarchy_setup": {
        "commandId": "20",
        "key": [
            "pt",
            "unit",
            "divisi"
        ],
        "data_type": [
            "string",
            "string",
            "string"
        ],
        "data_len": [
            50,
            25,
            25
        ],
        "default": [
            "OWL",
            "OWLHO",
            "OWLHO-RND"
        ],
        "queue": "hierarchy_setupqueue",
        "path": "/hierarchy_setup"
    },
    "fingerprint_setup": {
        "commandId": "21",
        "key": [
            "security_level",
            "flag_absen",
            "gps_validation",
            "geofencing",
            "geofencing_lat",
            "geofencing_lng",
            "geofencing_radius",
            "scan_mode",
            "operation_mode"
        ],
        "data_type": [
            "uint8_t",
            "uint8_t",
            "bool",
            "bool",
            "float",
            "float",
            "float",
            "bool",
            "bool"
        ],
        "data_len": [
            1,
            1,
            1,
            1,
            4,
            4,
            4,
            1,
            1
        ],
        "default": [
            4,
            2,
            false,
            false,
            0,
            0,
            5,
            false,
            true
        ],
        "queue": "fingerprint_setupqueue",
        "path": "/fingerprint_setup"
    },
    "stb_bandul_setup": {
        "commandId": "22",
        "key": [
            "bandul_id",
            "bandul_length"
        ],
        "data_type": [
            "uint32_t",
            "float"
        ],
        "data_len": [
            4,
            4
        ],
        "default": [
            0,
            21.5
        ],
        "queue": "stb_bandul_setupqueue",
        "path": "/stb_bandul_setup"
    },
    "pom_setup": {
        "commandId": "23",
        "key": [
            "konstanta",
            "validasi",
            "stock",
            "max_stock",
            "min_stock"
        ],
        "data_type": [
            "float",
            "bool",
            "float",
            "float",
            "float"
        ],
        "data_len": [
            4,
            1,
            4,
            4,
            4
        ],
        "default": [
            1,
            true,
            0,
            1000,
            0
        ],
        "queue": "pom_setupqueue",
        "path": "/pom_setup"
    },
    "stb_controller_setup": {
        "commandId": "25",
        "key": [
            "offset",
            "mejaukur",
            "crosscek",
            "filter_minyak_dari_bawah",
            "filter_minyak_dari_atas",
            "filter_gulungan_habis",
            "ignore",
            "speed_naik",
            "speed_turun",
            "timeout",
            "interval_cek_air",
            "loop_cek_air",
            "jarak_cek_air",
            "jarak_bersih",
            "loop_bersih",
            "validasi_deteksi",
            "tinggi_meja"
        ],
        "data_type": [
            "float",
            "float",
            "uint8_t",
            "float",
            "float",
            "float",
            "float",
            "int16_t",
            "int16_t",
            "uint32_t",
            "int16_t",
            "uint16_t",
            "uint8_t",
            "int16_t",
            "uint8_t",
            "int16_t",
            "float"
        ],
        "data_len": [
            4,
            4,
            1,
            4,
            4,
            4,
            4,
            2,
            2,
            4,
            2,
            2,
            1,
            2,
            1,
            2,
            4
        ],
        "default": [
            10.5,
            1340,
            3,
            1.13,
            1.3,
            2,
            5,
            -18,
            20,
            36000,
            1,
            5,
            0,
            20,
            3,
            30,
            0
        ],
        "queue": "stb_controller_setupqueue",
        "path": "/stb_controller_setup"
    },
    "stb_mekanikal_setup": {
        "commandId": "26",
        "key": [
            "mekanikal_id",
            "maxrange",
            "opto_timeout_naik",
            "pwm_off",
            "limit_switch",
            "pressure_switch",
            "pwm_resolution"
        ],
        "data_type": [
            "uint32_t",
            "float",
            "uint16_t",
            "int16_t",
            "bool",
            "bool",
            "uint8_t"
        ],
        "data_len": [
            4,
            4,
            2,
            2,
            1,
            1,
            1
        ],
        "default": [
            0,
            1500,
            600,
            307,
            true,
            true,
            12
        ],
        "queue": "stb_mekanikal_setupqueue",
        "path": "/stb_mekanikal_setup"
    },
    "tracker_setup": {
        "commandId": "27",
        "key": [
            "karyawan_name",
            "activity_id",
            "latitude",
            "longitude",
            "radius",
            "geofence",
            "com_mode"
        ],
        "data_type": [
            "string",
            "uint32_t",
            "float",
            "float",
            "float",
            "bool",
            "uint8_t"
        ],
        "data_len": [
            40,
            4,
            4,
            4,
            4,
            1,
            1
        ],
        "default": [
            "Ahmad",
            3,
            0,
            0,
            1,
            false,
            0
        ],
        "queue": "tracker_setupqueue",
        "path": "/tracker_setup"
    },
    "stb_controller_sub_setup": {
        "commandId": "28",
        "key": [
            "interval_air",
            "loop_air",
            "loop_bersih",
            "jarak_bersih",
            "validate_detection"
        ],
        "data_type": [
            "uint8_t",
            "uint16_t",
            "uint8_t",
            "uint16_t",
            "uint8_t"
        ],
        "data_len": [
            1,
            2,
            1,
            2,
            1
        ],
        "default": [
            1,
            5,
            4,
            20,
            30
        ],
        "queue": "stb_controller_sub_setupqueue",
        "path": "/stb_controller_sub_setup"
    },
    "esp_now": {
        "commandId": "31",
        "key": [
            "channel",
            "longrange"
        ],
        "data_type": [
            "uint8_t",
            "bool"
        ],
        "data_len": [
            1,
            1
        ],
        "default": [
            1,
            true
        ],
        "queue": "esp_nowqueue",
        "path": "/esp_now"
    },
    "functional_flag": {
        "commandId": "32",
        "key": [
            "ble_state",
            "mqtt_state",
            "radio_state",
            "schedule_state",
            "gps_state",
            "espnow_state"
        ],
        "data_type": [
            "bool",
            "bool",
            "bool",
            "bool",
            "bool",
            "bool"
        ],
        "data_len": [
            1,
            1,
            1,
            1,
            1,
            1
        ],
        "default": [
            true,
            true,
            true,
            true,
            true,
            false
        ],
        "queue": "functional_flagqueue",
        "path": "/functional_flag"
    }
}
)";