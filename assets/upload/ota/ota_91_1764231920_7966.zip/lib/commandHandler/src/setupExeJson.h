const char* setupExeJson=R"(
{
    "restart": {
        "commandId": "1",
        "key": [
            "state"
        ],
        "data_type": [
            "bool"
        ],
        "data_len": [
            1
        ]
    },
    "file_read": {
        "commandId": "2",
        "key": [
            "path"
        ],
        "data_type": [
            "string"
        ],
        "data_len": [
            50
        ]
    },
    "file_write": {
        "commandId": "3",
        "key": [
            "path"
        ],
        "data_type": [
            "string"
        ],
        "data_len": [
            50
        ]
    },
    "file_append": {
        "commandId": "4",
        "key": [
            "path"
        ],
        "data_type": [
            "string"
        ],
        "data_len": [
            50
        ]
    },
    "file_delete": {
        "commandId": "5",
        "key": [
            "path"
        ],
        "data_type": [
            "string"
        ],
        "data_len": [
            50
        ]
    },
    "pom_receive": {
        "commandId": "9",
        "key": [
            "transaksi_id",
            "liter",
            "plat",
            "karyawan_id"
        ],
        "data_type": [
            "uint32_t",
            "float",
            "string",
            "uint32_t"
        ],
        "data_len": [
            4,
            4,
            15,
            4
        ]
    },
    "query_sql": {
        "commandId": "10",
        "key": [
            "db_path",
            "query"
        ],
        "data_type": [
            "string",
            "string"
        ],
        "data_len": [
            40,
            300
        ]
    },
    "fingerprint_register": {
        "commandId": "11",
        "key": [
            "nama",
            "karyawan_id",
            "kode_jari"
        ],
        "data_type": [
            "string",
            "uint32_t",
            "uint8_t"
        ],
        "data_len": [
            40,
            4,
            1
        ]
    },
    "backup_template_fp": {
        "commandId": "12",
        "key": [
            "karyawan_id"
        ],
        "data_type": [
            "uint32_t"
        ],
        "data_len": [
            4
        ]
    },
    "restore_template_fp": {
        "commandId": "13",
        "key": [
            "nama",
            "karyawan_id",
            "kode_jari",
            "template_fp"
        ],
        "data_type": [
            "string",
            "uint32_t",
            "uint8_t",
            "string"
        ],
        "data_len": [
            40,
            4,
            1,
            2300
        ]
    },
    "delete_template_fp": {
        "commandId": "14",
        "key": [
            "karyawan_id"
        ],
        "data_type": [
            "uint32_t"
        ],
        "data_len": [
            4
        ]
    },
    "admin_fp": {
        "commandId": "15",
        "key": [
            "karyawan_id",
            "privilege"
        ],
        "data_type": [
            "uint32_t",
            "string"
        ],
        "data_len": [
            4,
            200
        ]
    },
    "get_info": {
        "commandId": "16",
        "key": [
            "state"
        ],
        "data_type": [
            "bool"
        ],
        "data_len": [
            1
        ]
    },
    "factory_reset": {
        "commandId": "17",
        "key": [
            "state"
        ],
        "data_type": [
            "bool"
        ],
        "data_len": [
            1
        ]
    },
    "fingerprint_scan": {
        "commandId": "19",
        "key": [
            "nama",
            "karyawan_id",
            "kode_jari"
        ],
        "data_type": [
            "string",
            "uint32_t",
            "int8_t"
        ],
        "data_len": [
            40,
            4,
            1
        ]
    },
    "stb_move_to": {
        "commandId": "20",
        "key": [
            "pwm",
            "jarak"
        ],
        "data_type": [
            "int16_t",
            "float"
        ],
        "data_len": [
            2,
            4
        ]
    },
    "stb_move_detection": {
        "commandId": "21",
        "key": [
            "pwm",
            "filter",
            "ignore",
            "crosscek",
            "maxrange"
        ],
        "data_type": [
            "int16_t",
            "float",
            "float",
            "uint8_t",
            "float"
        ],
        "data_len": [
            2,
            4,
            4,
            1,
            4
        ]
    },
    "stb_sounding": {
        "commandId": "22",
        "key": [
            "state"
        ],
        "data_type": [
            "bool"
        ],
        "data_len": [
            1
        ]
    },
    "stb_sounding_all": {
        "commandId": "23",
        "key": [
            "offset",
            "linier_constant",
            "maxrange",
            "mejaukur",
            "crosscek",
            "filter",
            "filter_turun",
            "filter_habis",
            "offset_atas",
            "ignore",
            "speed_naik",
            "speed_turun"
        ],
        "data_type": [
            "float",
            "float",
            "float",
            "float",
            "uint8_t",
            "float",
            "float",
            "float",
            "float",
            "float",
            "int16_t",
            "int16_t"
        ],
        "data_len": [
            4,
            4,
            4,
            4,
            1,
            4,
            4,
            4,
            4,
            4,
            2,
            2
        ]
    },
    "save_ir": {
        "commandId": "24",
        "key": [
            "ir_name"
        ],
        "data_type": [
            "string"
        ],
        "data_len": [
            50
        ]
    },
    "execute_ir": {
        "commandId": "25",
        "key": [
            "ir_name"
        ],
        "data_type": [
            "string"
        ],
        "data_len": [
            50
        ]
    },
    "get_ir_list": {
        "commandId": "26",
        "key": [],
        "data_type": [],
        "data_len": []
    },
    "schedule_daily": {
        "commandId": "27",
        "key": [
            "day",
            "minute",
            "everyday",
            "command"
        ],
        "data_type": [
            "uint8_t",
            "uint8_t",
            "bool",
            "object"
        ],
        "data_len": [
            1,
            1,
            1,
            2500
        ]
    },
    "schedule_monthly": {
        "commandId": "29",
        "key": [
            "month",
            "date",
            "hour",
            "minute",
            "everymonth",
            "command"
        ],
        "data_type": [
            "uint8_t",
            "uint8_t",
            "uint8_t",
            "uint8_t",
            "bool",
            "object"
        ],
        "data_len": [
            1,
            1,
            1,
            1,
            1,
            2500
        ]
    },
    "file_list": {
        "commandId": "31",
        "key": [
            "path"
        ],
        "data_type": [
            "string"
        ],
        "data_len": [
            50
        ]
    },
    "get_schedule": {
        "commandId": "32",
        "key": [
            "date"
        ],
        "data_type": [
            "string"
        ],
        "data_len": [
            20
        ]
    },
    "command_to_bandul": {
        "commandId": "33",
        "key": [
            "command"
        ],
        "data_type": [
            "object"
        ],
        "data_len": [
            1000
        ]
    },
    "soil_measure": {
        "commandId": "35",
        "key": [
            "state"
        ],
        "data_type": [
            "bool"
        ],
        "data_len": [
            1
        ]
    },
    "message_from_gateway": {
        "commandId": "36",
        "key": [
            "to",
            "message"
        ],
        "data_type": [
            "uint32_t",
            "string"
        ],
        "data_len": [
            4,
            230
        ]
    },
    "message_from_node": {
        "commandId": "37",
        "key": [
            "to",
            "message"
        ],
        "data_type": [
            "uint32_t",
            "string"
        ],
        "data_len": [
            4,
            200
        ]
    },
    "command_radio": {
        "commandId": "38",
        "key": [
            "to",
            "command"
        ],
        "data_type": [
            "uint32_t",
            "object"
        ],
        "data_len": [
            4,
            2000
        ]
    },
    "command_to_mekanikal": {
        "commandId": "39",
        "key": [
            "command",
            "timeout"
        ],
        "data_type": [
            "object",
            "uint16_t"
        ],
        "data_len": [
            2000,
            2
        ]
    },
    "get_bandul_data": {
        "commandId": "40",
        "key": [
            "timeout"
        ],
        "data_type": [
            "uint32_t"
        ],
        "data_len": [
            4
        ]
    },
    "get_data": {
        "commandId": "41",
        "key": [
            "data_name",
            "index",
            "limit",
            "is_backup",
            "send_to"
        ],
        "data_type": [
            "string",
            "uint32_t",
            "uint32_t",
            "bool",
            "string"
        ],
        "data_len": [
            50,
            4,
            4,
            1,
            15
        ]
    },
    "update_mekanikal": {
        "commandId": "42",
        "key": [
            "timeout",
            "otaurl"
        ],
        "data_type": [
            "uint32_t",
            "string"
        ],
        "data_len": [
            4,
            100
        ]
    },
    "upload_data": {
        "commandId": "43",
        "key": [],
        "data_type": [],
        "data_len": []
    },
    "check_data": {
        "commandId": "44",
        "key": [
            "data_name",
            "is_backup"
        ],
        "data_type": [
            "string",
            "bool"
        ],
        "data_len": [
            50,
            1
        ]
    },
    "clear_schedule": {
        "commandId": "45",
        "key": [
            "state"
        ],
        "data_type": [
            "bool"
        ],
        "data_len": [
            1
        ]
    },
    "stb_check_air": {
        "commandId": "46",
        "key": [
            "state"
        ],
        "data_type": [
            "bool"
        ],
        "data_len": [
            1
        ]
    }
}
)";