#ifndef COMMANDHANDLERQUEUE_H
#define COMMANDHANDLERQUEUE_H
#include <Arduino.h>

extern SemaphoreHandle_t mutex_handler;

// Queue Declarations
extern QueueHandle_t wifiQueue;
extern QueueHandle_t mqttQueue;
extern QueueHandle_t intervalQueue;
extern QueueHandle_t utcoffsetQueue;
extern QueueHandle_t last_epochQueue;
extern QueueHandle_t keyQueue;
extern QueueHandle_t use_keyQueue;
extern QueueHandle_t snQueue;
extern QueueHandle_t otaurlQueue;
extern QueueHandle_t api_ver1Queue;
extern QueueHandle_t api_ver2Queue;
extern QueueHandle_t adv_bleQueue;
extern QueueHandle_t radio_modeQueue;
extern QueueHandle_t radio_param_1Queue;
extern QueueHandle_t radio_param_2Queue;
extern QueueHandle_t radio_param_3Queue;
extern QueueHandle_t radio_param_4Queue;
extern QueueHandle_t licenseQueue;
extern QueueHandle_t suspendQueue;
extern QueueHandle_t hierarchy_setupQueue;
extern QueueHandle_t fingerprint_setupQueue;
extern QueueHandle_t stb_bandul_setupQueue;
extern QueueHandle_t pom_setupQueue;
extern QueueHandle_t stb_controller_setupQueue;
extern QueueHandle_t stb_mekanikal_setupQueue;
extern QueueHandle_t tracker_setupQueue;
extern QueueHandle_t stb_controller_sub_setupQueue;
extern QueueHandle_t esp_nowQueue;
extern QueueHandle_t functional_flagQueue;



// Struct Definitions
#pragma pack(1)

struct headerRadioStruct {
    uint32_t to;
    uint32_t from;
    uint16_t id_message;
    uint8_t type;
    uint16_t key;
    uint16_t commandId;
    uint8_t data [512];
    uint16_t len; 
  };
  
  struct headerCommandStruct {
    uint16_t id_message;
    uint8_t type;
    uint16_t key;
    uint16_t commandId;
    uint8_t data [512];
    uint16_t len; 
  };

struct wifi_struct {
    char ssid[25];
    char password[25];
};

struct mqtt_struct {
    char host[125];
    uint16_t port;
    char username[25];
    char password[25];
};

struct interval_struct {
    uint32_t get_data;
    uint32_t upload_data;
    uint32_t standby;
    uint32_t heartbeat;
    uint32_t backup_data;
    uint32_t delete_data;
    uint32_t wifireconnect;
    uint32_t mqttreconnect;
    uint32_t radioreconnect;
};

struct utcoffset_struct {
    uint32_t utcoffset;
};

struct last_epoch_struct {
    uint32_t epoch;
};

struct key_struct {
    uint16_t key;
};

struct use_key_struct {
    bool state;
};

struct sn_struct {
    uint32_t sn;
    char alias[15];
};

struct otaurl_struct {
    char otaurl[125];
};

struct api_ver1_struct {
    char method[150];
    char api[200];
};

struct api_ver2_struct {
    char username[30];
    char client_id[40];
    char client_secret[100];
    char api_key[100];
};

struct adv_ble_struct {
    bool state;
};

struct radio_mode_struct {
    uint8_t channel;
    bool is_fsk;
    uint32_t gateway_id;
    uint16_t randomness;
};

struct radio_param_1_struct {
    float bandwidth;
    float tx;
    float rx;
    uint8_t cr;
    uint8_t sf;
    uint8_t db;
    float bitrate;
};

struct radio_param_2_struct {
    float bandwidth;
    float tx;
    float rx;
    uint8_t cr;
    uint8_t sf;
    uint8_t db;
    float bitrate;
};

struct radio_param_3_struct {
    float bandwidth;
    float tx;
    float rx;
    uint8_t cr;
    uint8_t sf;
    uint8_t db;
    float bitrate;
};

struct radio_param_4_struct {
    float bandwidth;
    float tx;
    float rx;
    uint8_t cr;
    uint8_t sf;
    uint8_t db;
    float bitrate;
};

struct license_struct {
    char license[80];
};

struct suspend_struct {
    bool state;
};

struct hierarchy_setup_struct {
    char pt[50];
    char unit[25];
    char divisi[25];
};

struct fingerprint_setup_struct {
    uint8_t security_level;
    uint8_t flag_absen;
    bool gps_validation;
    bool geofencing;
    float geofencing_lat;
    float geofencing_lng;
    float geofencing_radius;
    bool scan_mode;
    bool operation_mode;
};

struct stb_bandul_setup_struct {
    uint32_t bandul_id;
    float bandul_length;
};

struct pom_setup_struct {
    float konstanta;
    bool validasi;
    float stock;
    float max_stock;
    float min_stock;
};

struct stb_controller_setup_struct {
    float offset;
    float mejaukur;
    uint8_t crosscek;
    float filter_minyak_dari_bawah;
    float filter_minyak_dari_atas;
    float filter_gulungan_habis;
    float ignore;
    int16_t speed_naik;
    int16_t speed_turun;
    uint32_t timeout;
    int16_t interval_cek_air;
    uint16_t loop_cek_air;
    uint8_t jarak_cek_air;
    int16_t jarak_bersih;
    uint8_t loop_bersih;
    int16_t validasi_deteksi;
    float tinggi_meja;
};

struct stb_mekanikal_setup_struct {
    uint32_t mekanikal_id;
    float maxrange;
    uint16_t opto_timeout_naik;
    int16_t pwm_off;
    bool limit_switch;
    bool pressure_switch;
    uint8_t pwm_resolution;
};

struct tracker_setup_struct {
    char karyawan_name[40];
    uint32_t activity_id;
    float latitude;
    float longitude;
    float radius;
    bool geofence;
    uint8_t com_mode;
};

struct stb_controller_sub_setup_struct {
    uint8_t interval_air;
    uint16_t loop_air;
    uint8_t loop_bersih;
    uint16_t jarak_bersih;
    uint8_t validate_detection;
};

struct esp_now_struct {
    uint8_t channel;
    bool longrange;
};

struct functional_flag_struct {
    bool ble_state;
    bool mqtt_state;
    bool radio_state;
    bool schedule_state;
    bool gps_state;
    bool espnow_state;
};

struct restart_struct {
    bool state;
};

struct file_read_struct {
    char path[50];
};

struct file_write_struct {
    char path[50];
};

struct file_append_struct {
    char path[50];
};

struct file_delete_struct {
    char path[50];
};

struct pom_receive_struct {
    uint32_t transaksi_id;
    float liter;
    char plat[15];
    uint32_t karyawan_id;
};

struct query_sql_struct {
    char db_path[40];
    char query[300];
};

struct fingerprint_register_struct {
    char nama[40];
    uint32_t karyawan_id;
    uint8_t kode_jari;
};

struct backup_template_fp_struct {
    uint32_t karyawan_id;
};

struct restore_template_fp_struct {
    char nama[40];
    uint32_t karyawan_id;
    uint8_t kode_jari;
    char template_fp[2300];
};

struct delete_template_fp_struct {
    uint32_t karyawan_id;
};

struct admin_fp_struct {
    uint32_t karyawan_id;
    char privilege[200];
};

struct get_info_struct {
    bool state;
};

struct factory_reset_struct {
    bool state;
};

struct fingerprint_scan_struct {
    char nama[40];
    uint32_t karyawan_id;
    int8_t kode_jari;
};

struct stb_move_to_struct {
    int16_t pwm;
    float jarak;
};

struct stb_move_detection_struct {
    int16_t pwm;
    float filter;
    float ignore;
    uint8_t crosscek;
    float maxrange;
};

struct stb_sounding_struct {
    bool state;
};

struct stb_sounding_all_struct {
    float offset;
    float linier_constant;
    float maxrange;
    float mejaukur;
    uint8_t crosscek;
    float filter;
    float filter_turun;
    float filter_habis;
    float offset_atas;
    float ignore;
    int16_t speed_naik;
    int16_t speed_turun;
};

struct save_ir_struct {
    char ir_name[50];
};

struct execute_ir_struct {
    char ir_name[50];
};

struct get_ir_list_struct {
};

struct schedule_daily_struct {
    uint8_t day;
    uint8_t minute;
    bool everyday;
    JsonDocument command;
};

struct schedule_monthly_struct {
    uint8_t month;
    uint8_t date;
    uint8_t hour;
    uint8_t minute;
    bool everymonth;
    JsonDocument command;
};

struct file_list_struct {
    char path[50];
};

struct get_schedule_struct {
    char date[20];
};

struct command_to_bandul_struct {
    JsonDocument command;
};

struct soil_measure_struct {
    bool state;
};

struct message_from_gateway_struct {
    uint32_t to;
    char message[230];
};

struct message_from_node_struct {
    uint32_t to;
    char message[200];
};

struct command_radio_struct {
    uint32_t to;
    JsonDocument command;
};

struct command_to_mekanikal_struct {
    JsonDocument command;
    uint16_t timeout;
};

struct get_bandul_data_struct {
    uint32_t timeout;
};

struct get_data_struct {
    char data_name[50];
    uint32_t index;
    uint32_t limit;
    bool is_backup;
    char send_to[15];
};

struct update_mekanikal_struct {
    uint32_t timeout;
    char otaurl[100];
};

struct upload_data_struct {
};

struct check_data_struct {
    char data_name[50];
    bool is_backup;
};

struct clear_schedule_struct {
    bool state;
};

struct stb_check_air_struct {
    bool state;
};

struct pom_data_struct {
    uint32_t transaksi_id;
    float liter;
    char plat[15];
    uint32_t karyawan_id;
    float stock;
    char date[23];
};

struct radio_pooling_data_struct {
    uint8_t repeater_number;
    uint32_t repeater_1;
    uint32_t repeater_2;
    uint32_t repeater_3;
    uint32_t repeater_4;
    uint32_t repeater_5;
};

struct bandul_data_struct {
    int8_t baterai;
    uint32_t count;
    float min_temp_bandul;
    float avg_temp_bandul;
    float max_temp_bandul;
    float avg_temp_probe;
    float air;
    float lumpur;
    uint32_t sync;
};

struct logger_gps_data_struct {
    uint32_t activity_id;
    uint8_t battery;
    float latitude;
    uint32_t recorded_at;
};

struct logger_vehicle_gps_data_struct {
    uint32_t karyawan_id;
    uint32_t activity_id;
    float latitude;
    float longitude;
    float altitude;
    float speed;
    float maxspeed;
    float trip;
    float fuel;
    uint32_t recorded_at;
};

struct radio_broadcast_data_struct {
    uint32_t unix_time;
    uint8_t interval_broadcast;
    uint8_t channel;
};

struct radio_join_data_struct {
    bool state;
};

struct radio_response_data_struct {
    bool status;
    uint32_t status_code;
};

struct stb_notification_struct {
    char status[10];
    uint32_t status_error;
    char step[20];
    char description[100];
    uint32_t unix;
    float jarak;
};

struct stb_sounding_data_struct {
    float tinggi_minyak_dari_atas;
    float tinggi_minyak_dari_bawah;
    float tinggi_udara_dari_atas;
    float tinggi_udara_dari_bawah;
    float suhu;
    float baterai_bandul;
    bool status;
    uint32_t error_code;
    float average_1;
    float average_2;
    int16_t speed_naik;
    int16_t speed_turun;
    float mejaukur;
    float minyak;
    float air;
    float lumpur;
    float tinggi_meja;
    float deviasi;
    float v_charge;
    float suhu_rtc;
    float suhu_bandul;
    float suhu_probe;
    float suhu_mek;
    uint32_t recorded_at;
};

struct soil_data_struct {
    char recorded_at[20];
};

struct stb_data_air_struct {
    float air;
    float lumpur;
    float baterai_bandul;
    float suhu;
    float tinggi_air_lumpur;
};



#pragma pack()
#endif
