#ifndef GPSAPP_H_
#define GPSAPP_H_
//------------------NECESSARY-----------
#include <Arduino.h>
#include <commonvar.h>
#include <commondef.h>
#include <TinyGPS++.h>
#include <commandHandlerQueue.h>  

bool gps_task();

#endif