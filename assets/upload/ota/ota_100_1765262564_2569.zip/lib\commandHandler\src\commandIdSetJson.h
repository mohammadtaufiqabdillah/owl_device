const char* commandIdSetJson = R"(
{
    "6": "wifi",
    "8": "interval"
}
)";
