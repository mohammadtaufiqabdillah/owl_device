#ifndef COMMANDHANDLERQUEUE_H
#define COMMANDHANDLERQUEUE_H
#include <Arduino.h>

extern SemaphoreHandle_t mutex_handler;

// Queue Declarations
extern QueueHandle_t wifiQueue;
extern QueueHandle_t intervalQueue;
extern QueueHandle_t utcoffsetQueue;
extern QueueHandle_t last_epochQueue;
extern QueueHandle_t keyQueue;
extern QueueHandle_t use_keyQueue;
extern QueueHandle_t snQueue;
extern QueueHandle_t otaurlQueue;
extern QueueHandle_t adv_bleQueue;
extern QueueHandle_t licenseQueue;
extern QueueHandle_t suspendQueue;
extern QueueHandle_t hierarchy_setupQueue;
extern QueueHandle_t esp_nowQueue;



// Struct Definitions
#pragma pack(1)

struct headerRadioStruct {
    uint32_t to;
    uint32_t from;
    uint16_t id_message;
    uint8_t type;
    uint16_t key;
    uint16_t commandId;
    uint8_t data [512];
    uint16_t len; 
  };
  
  struct headerCommandStruct {
    uint16_t id_message;
    uint8_t type;
    uint16_t key;
    uint16_t commandId;
    uint8_t data [512];
    uint16_t len; 
  };

struct wifi_struct {
    char ssid[25];
    char password[25];
};

struct interval_struct {
    uint32_t get_data;
    uint32_t upload_data;
    uint32_t standby;
    uint32_t heartbeat;
    uint32_t backup_data;
    uint32_t delete_data;
    uint32_t wifireconnect;
    uint32_t mqttreconnect;
    uint32_t radioreconnect;
};

struct utcoffset_struct {
    uint32_t utcoffset;
};

struct last_epoch_struct {
    uint32_t epoch;
};

struct key_struct {
    uint16_t key;
};

struct use_key_struct {
    bool state;
};

struct sn_struct {
    uint32_t sn;
    char alias[15];
};

struct otaurl_struct {
    char otaurl[125];
};

struct adv_ble_struct {
    bool state;
};

struct license_struct {
    char license[80];
};

struct suspend_struct {
    bool state;
};

struct hierarchy_setup_struct {
    char pt[50];
    char unit[25];
    char divisi[25];
};

struct esp_now_struct {
    uint8_t channel;
    bool longrange;
};

struct restart_struct {
    bool state;
};

struct file_read_struct {
    char path[50];
};

struct file_write_struct {
    char path[50];
};

struct file_append_struct {
    char path[50];
};

struct file_delete_struct {
    char path[50];
};

struct bandul_data_struct {
    int8_t baterai;
    uint32_t count;
    float min_temp_bandul;
    float avg_temp_bandul;
    float max_temp_bandul;
    float avg_temp_probe;
    float air;
    float lumpur;
    uint32_t sync;
};

struct radio_response_data_struct {
    bool status;
    uint32_t status_code;
};



#pragma pack()
#endif
