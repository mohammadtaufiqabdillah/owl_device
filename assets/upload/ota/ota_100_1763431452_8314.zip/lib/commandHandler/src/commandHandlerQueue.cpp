#include "CommandHandler.h"

SemaphoreHandle_t mutex_handler;

// Queue Initializations
QueueHandle_t wifiQueue;
QueueHandle_t intervalQueue;
QueueHandle_t utcoffsetQueue;
QueueHandle_t last_epochQueue;
QueueHandle_t keyQueue;
QueueHandle_t use_keyQueue;
QueueHandle_t snQueue;
QueueHandle_t otaurlQueue;
QueueHandle_t adv_bleQueue;
QueueHandle_t licenseQueue;
QueueHandle_t suspendQueue;
QueueHandle_t hierarchy_setupQueue;
QueueHandle_t esp_nowQueue;


// Initialize the queue
void CommandHandler::queueBegin(){
    mutex_handler = xSemaphoreCreateRecursiveMutex(); 
        wifiQueue = xQueueCreate(1, 1);
    intervalQueue = xQueueCreate(1, 1);
    utcoffsetQueue = xQueueCreate(1, 1);
    last_epochQueue = xQueueCreate(1, 1);
    keyQueue = xQueueCreate(1, 1);
    use_keyQueue = xQueueCreate(1, 1);
    snQueue = xQueueCreate(1, 1);
    otaurlQueue = xQueueCreate(1, 1);
    adv_bleQueue = xQueueCreate(1, 1);
    licenseQueue = xQueueCreate(1, 1);
    suspendQueue = xQueueCreate(1, 1);
    hierarchy_setupQueue = xQueueCreate(1, 1);
    esp_nowQueue = xQueueCreate(1, 1);

}

// Send settings to the specified RTOS queue
void CommandHandler::sendToQueue(const char* queueName, bool status) {
    JsonDocument doc;
    bool newValues = status;

    if (strcmp(queueName, "wifiqueue") == 0) {
    if (wifiQueue != NULL) {
        xQueueOverwrite(wifiQueue, &newValues);
    }
}
else if (strcmp(queueName, "intervalqueue") == 0) {
    if (intervalQueue != NULL) {
        xQueueOverwrite(intervalQueue, &newValues);
    }
}
else if (strcmp(queueName, "utcoffsetqueue") == 0) {
    if (utcoffsetQueue != NULL) {
        xQueueOverwrite(utcoffsetQueue, &newValues);
    }
}
else if (strcmp(queueName, "last_epochqueue") == 0) {
    if (last_epochQueue != NULL) {
        xQueueOverwrite(last_epochQueue, &newValues);
    }
}
else if (strcmp(queueName, "keyqueue") == 0) {
    if (keyQueue != NULL) {
        xQueueOverwrite(keyQueue, &newValues);
    }
}
else if (strcmp(queueName, "use_keyqueue") == 0) {
    if (use_keyQueue != NULL) {
        xQueueOverwrite(use_keyQueue, &newValues);
    }
}
else if (strcmp(queueName, "snqueue") == 0) {
    if (snQueue != NULL) {
        xQueueOverwrite(snQueue, &newValues);
    }
}
else if (strcmp(queueName, "otaurlqueue") == 0) {
    if (otaurlQueue != NULL) {
        xQueueOverwrite(otaurlQueue, &newValues);
    }
}
else if (strcmp(queueName, "adv_blequeue") == 0) {
    if (adv_bleQueue != NULL) {
        xQueueOverwrite(adv_bleQueue, &newValues);
    }
}
else if (strcmp(queueName, "licensequeue") == 0) {
    if (licenseQueue != NULL) {
        xQueueOverwrite(licenseQueue, &newValues);
    }
}
else if (strcmp(queueName, "suspendqueue") == 0) {
    if (suspendQueue != NULL) {
        xQueueOverwrite(suspendQueue, &newValues);
    }
}
else if (strcmp(queueName, "hierarchy_setupqueue") == 0) {
    if (hierarchy_setupQueue != NULL) {
        xQueueOverwrite(hierarchy_setupQueue, &newValues);
    }
}
else if (strcmp(queueName, "esp_nowqueue") == 0) {
    if (esp_nowQueue != NULL) {
        xQueueOverwrite(esp_nowQueue, &newValues);
    }
}

}

//load struct overload function
bool CommandHandler::loadStruct(wifi_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("wifi",doc)){
    strcpy(structData.ssid, doc["data"]["ssid"]);
    strcpy(structData.password, doc["data"]["password"]);
    return true;
}
if(!internal && loadSettings("wifi",doc)){
    strcpy(structData.ssid, doc["data"]["ssid"]);
    strcpy(structData.password, doc["data"]["password"]);
    return true;
}
else if(!hasValue){
    strcpy(structData.ssid, setupDoc["wifi"]["default"][0]);
    strcpy(structData.password, setupDoc["wifi"]["default"][1]);
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="wifi";
    (*docResult)["data"]["ssid"]=structData.ssid;
    (*docResult)["data"]["password"]=structData.password;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(interval_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("interval",doc)){
    structData.get_data = doc["data"]["get_data"];
    structData.upload_data = doc["data"]["upload_data"];
    structData.standby = doc["data"]["standby"];
    structData.heartbeat = doc["data"]["heartbeat"];
    structData.backup_data = doc["data"]["backup_data"];
    structData.delete_data = doc["data"]["delete_data"];
    structData.wifireconnect = doc["data"]["wifireconnect"];
    structData.mqttreconnect = doc["data"]["mqttreconnect"];
    structData.radioreconnect = doc["data"]["radioreconnect"];
    return true;
}
if(!internal && loadSettings("interval",doc)){
    structData.get_data = doc["data"]["get_data"];
    structData.upload_data = doc["data"]["upload_data"];
    structData.standby = doc["data"]["standby"];
    structData.heartbeat = doc["data"]["heartbeat"];
    structData.backup_data = doc["data"]["backup_data"];
    structData.delete_data = doc["data"]["delete_data"];
    structData.wifireconnect = doc["data"]["wifireconnect"];
    structData.mqttreconnect = doc["data"]["mqttreconnect"];
    structData.radioreconnect = doc["data"]["radioreconnect"];
    return true;
}
else if(!hasValue){
    structData.get_data = setupDoc["interval"]["default"][0];
    structData.upload_data = setupDoc["interval"]["default"][1];
    structData.standby = setupDoc["interval"]["default"][2];
    structData.heartbeat = setupDoc["interval"]["default"][3];
    structData.backup_data = setupDoc["interval"]["default"][4];
    structData.delete_data = setupDoc["interval"]["default"][5];
    structData.wifireconnect = setupDoc["interval"]["default"][6];
    structData.mqttreconnect = setupDoc["interval"]["default"][7];
    structData.radioreconnect = setupDoc["interval"]["default"][8];
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="interval";
    (*docResult)["data"]["get_data"]=structData.get_data;
    (*docResult)["data"]["upload_data"]=structData.upload_data;
    (*docResult)["data"]["standby"]=structData.standby;
    (*docResult)["data"]["heartbeat"]=structData.heartbeat;
    (*docResult)["data"]["backup_data"]=structData.backup_data;
    (*docResult)["data"]["delete_data"]=structData.delete_data;
    (*docResult)["data"]["wifireconnect"]=structData.wifireconnect;
    (*docResult)["data"]["mqttreconnect"]=structData.mqttreconnect;
    (*docResult)["data"]["radioreconnect"]=structData.radioreconnect;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(utcoffset_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("utcoffset",doc)){
    structData.utcoffset = doc["data"]["utcoffset"];
    return true;
}
if(!internal && loadSettings("utcoffset",doc)){
    structData.utcoffset = doc["data"]["utcoffset"];
    return true;
}
else if(!hasValue){
    structData.utcoffset = setupDoc["utcoffset"]["default"][0];
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="utcoffset";
    (*docResult)["data"]["utcoffset"]=structData.utcoffset;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(last_epoch_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("last_epoch",doc)){
    structData.epoch = doc["data"]["epoch"];
    return true;
}
if(!internal && loadSettings("last_epoch",doc)){
    structData.epoch = doc["data"]["epoch"];
    return true;
}
else if(!hasValue){
    structData.epoch = setupDoc["last_epoch"]["default"][0];
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="last_epoch";
    (*docResult)["data"]["epoch"]=structData.epoch;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(key_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("key",doc)){
    structData.key = doc["data"]["key"];
    return true;
}
if(!internal && loadSettings("key",doc)){
    structData.key = doc["data"]["key"];
    return true;
}
else if(!hasValue){
    structData.key = setupDoc["key"]["default"][0];
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="key";
    (*docResult)["data"]["key"]=structData.key;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(use_key_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("use_key",doc)){
    structData.state = doc["data"]["state"];
    return true;
}
if(!internal && loadSettings("use_key",doc)){
    structData.state = doc["data"]["state"];
    return true;
}
else if(!hasValue){
    structData.state = setupDoc["use_key"]["default"][0];
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="use_key";
    (*docResult)["data"]["state"]=structData.state;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(sn_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("sn",doc)){
    structData.sn = doc["data"]["sn"];
    strcpy(structData.alias, doc["data"]["alias"]);
    return true;
}
if(!internal && loadSettings("sn",doc)){
    structData.sn = doc["data"]["sn"];
    strcpy(structData.alias, doc["data"]["alias"]);
    return true;
}
else if(!hasValue){
    structData.sn = setupDoc["sn"]["default"][0];
    strcpy(structData.alias, setupDoc["sn"]["default"][1]);
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="sn";
    (*docResult)["data"]["sn"]=structData.sn;
    (*docResult)["data"]["alias"]=structData.alias;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(otaurl_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("otaurl",doc)){
    strcpy(structData.otaurl, doc["data"]["otaurl"]);
    return true;
}
if(!internal && loadSettings("otaurl",doc)){
    strcpy(structData.otaurl, doc["data"]["otaurl"]);
    return true;
}
else if(!hasValue){
    strcpy(structData.otaurl, setupDoc["otaurl"]["default"][0]);
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="otaurl";
    (*docResult)["data"]["otaurl"]=structData.otaurl;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(adv_ble_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("adv_ble",doc)){
    structData.state = doc["data"]["state"];
    return true;
}
if(!internal && loadSettings("adv_ble",doc)){
    structData.state = doc["data"]["state"];
    return true;
}
else if(!hasValue){
    structData.state = setupDoc["adv_ble"]["default"][0];
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="adv_ble";
    (*docResult)["data"]["state"]=structData.state;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(license_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("license",doc)){
    strcpy(structData.license, doc["data"]["license"]);
    return true;
}
if(!internal && loadSettings("license",doc)){
    strcpy(structData.license, doc["data"]["license"]);
    return true;
}
else if(!hasValue){
    strcpy(structData.license, setupDoc["license"]["default"][0]);
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="license";
    (*docResult)["data"]["license"]=structData.license;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(suspend_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("suspend",doc)){
    structData.state = doc["data"]["state"];
    return true;
}
if(!internal && loadSettings("suspend",doc)){
    structData.state = doc["data"]["state"];
    return true;
}
else if(!hasValue){
    structData.state = setupDoc["suspend"]["default"][0];
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="suspend";
    (*docResult)["data"]["state"]=structData.state;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(hierarchy_setup_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("hierarchy_setup",doc)){
    strcpy(structData.pt, doc["data"]["pt"]);
    strcpy(structData.unit, doc["data"]["unit"]);
    strcpy(structData.divisi, doc["data"]["divisi"]);
    return true;
}
if(!internal && loadSettings("hierarchy_setup",doc)){
    strcpy(structData.pt, doc["data"]["pt"]);
    strcpy(structData.unit, doc["data"]["unit"]);
    strcpy(structData.divisi, doc["data"]["divisi"]);
    return true;
}
else if(!hasValue){
    strcpy(structData.pt, setupDoc["hierarchy_setup"]["default"][0]);
    strcpy(structData.unit, setupDoc["hierarchy_setup"]["default"][1]);
    strcpy(structData.divisi, setupDoc["hierarchy_setup"]["default"][2]);
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="hierarchy_setup";
    (*docResult)["data"]["pt"]=structData.pt;
    (*docResult)["data"]["unit"]=structData.unit;
    (*docResult)["data"]["divisi"]=structData.divisi;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(esp_now_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("esp_now",doc)){
    structData.channel = doc["data"]["channel"];
    structData.longrange = doc["data"]["longrange"];
    return true;
}
if(!internal && loadSettings("esp_now",doc)){
    structData.channel = doc["data"]["channel"];
    structData.longrange = doc["data"]["longrange"];
    return true;
}
else if(!hasValue){
    structData.channel = setupDoc["esp_now"]["default"][0];
    structData.longrange = setupDoc["esp_now"]["default"][1];
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="esp_now";
    (*docResult)["data"]["channel"]=structData.channel;
    (*docResult)["data"]["longrange"]=structData.longrange;
    return false;}


  return false;
}


