const char* commandIdSetJson=R"(
{
    "1": "wifi",
    "3": "interval",
    "4": "utcoffset",
    "5": "last_epoch",
    "6": "key",
    "7": "use_key",
    "8": "sn",
    "9": "otaurl",
    "12": "adv_ble",
    "18": "license",
    "19": "suspend",
    "20": "hierarchy_setup",
    "31": "esp_now"
}
)";