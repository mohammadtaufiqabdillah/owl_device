const char* commandIdExeJson=R"(
{
    "1": "restart",
    "2": "file_read",
    "3": "file_write",
    "4": "file_append",
    "5": "file_delete"
}
)";