const char* setupExeJson=R"(
{
    "restart": {
        "commandId": "1",
        "key": [
            "state"
        ],
        "data_type": [
            "bool"
        ],
        "data_len": [
            1
        ]
    },
    "file_read": {
        "commandId": "2",
        "key": [
            "path"
        ],
        "data_type": [
            "string"
        ],
        "data_len": [
            50
        ]
    },
    "file_write": {
        "commandId": "3",
        "key": [
            "path"
        ],
        "data_type": [
            "string"
        ],
        "data_len": [
            50
        ]
    },
    "file_append": {
        "commandId": "4",
        "key": [
            "path"
        ],
        "data_type": [
            "string"
        ],
        "data_len": [
            50
        ]
    },
    "file_delete": {
        "commandId": "5",
        "key": [
            "path"
        ],
        "data_type": [
            "string"
        ],
        "data_len": [
            50
        ]
    }
}
)";