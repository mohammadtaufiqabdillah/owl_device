const char* setupSetJson=R"(
{
    "wifi": {
        "commandId": "1",
        "key": [
            "ssid",
            "password"
        ],
        "data_type": [
            "string",
            "string"
        ],
        "data_len": [
            25,
            25
        ],
        "default": [
            "Devices",
            "87654321"
        ],
        "queue": "wifiqueue",
        "path": "/wifi"
    },
    "interval": {
        "commandId": "3",
        "key": [
            "get_data",
            "upload_data",
            "standby",
            "heartbeat",
            "backup_data",
            "delete_data",
            "wifireconnect",
            "mqttreconnect",
            "radioreconnect"
        ],
        "data_type": [
            "uint32_t",
            "uint32_t",
            "uint32_t",
            "uint32_t",
            "uint32_t",
            "uint32_t",
            "uint32_t",
            "uint32_t",
            "uint32_t"
        ],
        "data_len": [
            4,
            4,
            4,
            4,
            4,
            4,
            4,
            4,
            4
        ],
        "default": [
            60,
            600,
            60,
            60,
            600,
            360000,
            60,
            60,
            600
        ],
        "queue": "intervalqueue",
        "path": "/interval"
    },
    "utcoffset": {
        "commandId": "4",
        "key": [
            "utcoffset"
        ],
        "data_type": [
            "uint32_t"
        ],
        "data_len": [
            4
        ],
        "default": [
            7
        ],
        "queue": "utcoffsetqueue",
        "path": "/utcoffset"
    },
    "last_epoch": {
        "commandId": "5",
        "key": [
            "epoch"
        ],
        "data_type": [
            "uint32_t"
        ],
        "data_len": [
            4
        ],
        "default": [
            1000
        ],
        "queue": "last_epochqueue",
        "path": "/last_epoch"
    },
    "key": {
        "commandId": "6",
        "key": [
            "key"
        ],
        "data_type": [
            "uint16_t"
        ],
        "data_len": [
            2
        ],
        "default": [
            65535
        ],
        "queue": "keyqueue",
        "path": "/key"
    },
    "use_key": {
        "commandId": "7",
        "key": [
            "state"
        ],
        "data_type": [
            "bool"
        ],
        "data_len": [
            1
        ],
        "default": [
            false
        ],
        "queue": "use_keyqueue",
        "path": "/use_key"
    },
    "sn": {
        "commandId": "8",
        "key": [
            "sn",
            "alias"
        ],
        "data_type": [
            "uint32_t",
            "string"
        ],
        "data_len": [
            4,
            15
        ],
        "default": [
            99999,
            "FP11129"
        ],
        "queue": "snqueue",
        "path": "/sn"
    },
    "otaurl": {
        "commandId": "9",
        "key": [
            "otaurl"
        ],
        "data_type": [
            "string"
        ],
        "data_len": [
            125
        ],
        "default": [
            "http://103.150.191.136/owl_inventory/produksi/firmware.php"
        ],
        "queue": "otaurlqueue",
        "path": "/otaurl"
    },
    "adv_ble": {
        "commandId": "12",
        "key": [
            "state"
        ],
        "data_type": [
            "bool"
        ],
        "data_len": [
            1
        ],
        "default": [
            true
        ],
        "queue": "adv_blequeue",
        "path": "/adv_ble"
    },
    "license": {
        "commandId": "18",
        "key": [
            "license"
        ],
        "data_type": [
            "string"
        ],
        "data_len": [
            80
        ],
        "default": [
            "aaiu78198fh2iuhf98yy389h"
        ],
        "queue": "licensequeue",
        "path": "/license"
    },
    "suspend": {
        "commandId": "19",
        "key": [
            "state"
        ],
        "data_type": [
            "bool"
        ],
        "data_len": [
            1
        ],
        "default": [
            false
        ],
        "queue": "suspendqueue",
        "path": "/suspend"
    },
    "hierarchy_setup": {
        "commandId": "20",
        "key": [
            "pt",
            "unit",
            "divisi"
        ],
        "data_type": [
            "string",
            "string",
            "string"
        ],
        "data_len": [
            50,
            25,
            25
        ],
        "default": [
            "OWL",
            "OWLHO",
            "OWLHO-RND"
        ],
        "queue": "hierarchy_setupqueue",
        "path": "/hierarchy_setup"
    },
    "esp_now": {
        "commandId": "31",
        "key": [
            "channel",
            "longrange"
        ],
        "data_type": [
            "uint8_t",
            "bool"
        ],
        "data_len": [
            1,
            1
        ],
        "default": [
            1,
            true
        ],
        "queue": "esp_nowqueue",
        "path": "/esp_now"
    }
}
)";