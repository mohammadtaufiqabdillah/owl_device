const char* setupDatJson=R"(
{
    "bandul_data": {
        "commandId": "3",
        "key": [
            "baterai",
            "count",
            "min_temp_bandul",
            "avg_temp_bandul",
            "max_temp_bandul",
            "avg_temp_probe",
            "air",
            "lumpur",
            "sync"
        ],
        "data_type": [
            "int8_t",
            "uint32_t",
            "float",
            "float",
            "float",
            "float",
            "float",
            "float",
            "uint32_t"
        ],
        "data_len": [
            1,
            4,
            4,
            4,
            4,
            4,
            4,
            4,
            4
        ],
        "path": "/bandul_data"
    },
    "radio_response_data": {
        "commandId": "9",
        "key": [
            "status",
            "status_code"
        ],
        "data_type": [
            "bool",
            "uint32_t"
        ],
        "data_len": [
            1,
            4
        ],
        "path": "/radio_response_data"
    }
}
)";