const char* commandIdExeJson=R"(
{
    "1": "restart",
    "3": "file_write",
    "4": "file_append",
    "5": "file_delete",
    "20": "stb_move_to",
    "21": "stb_move_detection",
    "31": "file_list"
}
)";