const char* setupSetJson=R"(
{
    "use_key": {
        "commandId": "7",
        "key": [
            "state"
        ],
        "data_type": [
            "bool"
        ],
        "data_len": [
            1
        ],
        "default": [
            false
        ],
        "queue": "use_keyqueue",
        "path": "/use_key"
    },
    "stb_bandul_setup": {
        "commandId": "22",
        "key": [
            "bandul_id",
            "bandul_length"
        ],
        "data_type": [
            "uint32_t",
            "float"
        ],
        "data_len": [
            4,
            4
        ],
        "default": [
            0,
            21.5
        ],
        "queue": "stb_bandul_setupqueue",
        "path": "/stb_bandul_setup"
    },
    "stb_mekanikal_setup": {
        "commandId": "26",
        "key": [
            "mekanikal_id",
            "maxrange",
            "opto_timeout_naik",
            "pwm_off",
            "limit_switch",
            "pressure_switch",
            "pwm_resolution"
        ],
        "data_type": [
            "uint32_t",
            "float",
            "uint16_t",
            "int16_t",
            "bool",
            "bool",
            "uint8_t"
        ],
        "data_len": [
            4,
            4,
            2,
            2,
            1,
            1,
            1
        ],
        "default": [
            0,
            1500,
            600,
            307,
            true,
            true,
            12
        ],
        "queue": "stb_mekanikal_setupqueue",
        "path": "/stb_mekanikal_setup"
    }
}
)";