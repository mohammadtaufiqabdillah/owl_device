const char* setupExeJson=R"(
{
    "restart": {
        "commandId": "1",
        "key": [
            "state"
        ],
        "data_type": [
            "bool"
        ],
        "data_len": [
            1
        ]
    },
    "file_write": {
        "commandId": "3",
        "key": [
            "path"
        ],
        "data_type": [
            "string"
        ],
        "data_len": [
            50
        ]
    },
    "file_append": {
        "commandId": "4",
        "key": [
            "path"
        ],
        "data_type": [
            "string"
        ],
        "data_len": [
            50
        ]
    },
    "file_delete": {
        "commandId": "5",
        "key": [
            "path"
        ],
        "data_type": [
            "string"
        ],
        "data_len": [
            50
        ]
    },
    "stb_move_to": {
        "commandId": "20",
        "key": [
            "pwm",
            "jarak"
        ],
        "data_type": [
            "int16_t",
            "float"
        ],
        "data_len": [
            2,
            4
        ]
    },
    "stb_move_detection": {
        "commandId": "21",
        "key": [
            "pwm",
            "filter",
            "ignore",
            "crosscek",
            "maxrange"
        ],
        "data_type": [
            "int16_t",
            "float",
            "float",
            "uint8_t",
            "float"
        ],
        "data_len": [
            2,
            4,
            4,
            1,
            4
        ]
    },
    "file_list": {
        "commandId": "31",
        "key": [
            "path"
        ],
        "data_type": [
            "string"
        ],
        "data_len": [
            50
        ]
    }
}
)";