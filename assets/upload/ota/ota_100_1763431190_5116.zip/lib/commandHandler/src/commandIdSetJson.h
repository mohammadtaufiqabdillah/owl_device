const char* commandIdSetJson=R"(
{
    "7": "use_key",
    "22": "stb_bandul_setup",
    "26": "stb_mekanikal_setup"
}
)";