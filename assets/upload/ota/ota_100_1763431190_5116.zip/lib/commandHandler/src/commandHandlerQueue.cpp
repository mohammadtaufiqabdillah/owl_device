#include "CommandHandler.h"

SemaphoreHandle_t mutex_handler;

// Queue Initializations
QueueHandle_t use_keyQueue;
QueueHandle_t stb_bandul_setupQueue;
QueueHandle_t stb_mekanikal_setupQueue;


// Initialize the queue
void CommandHandler::queueBegin(){
    mutex_handler = xSemaphoreCreateRecursiveMutex(); 
        use_keyQueue = xQueueCreate(1, 1);
    stb_bandul_setupQueue = xQueueCreate(1, 1);
    stb_mekanikal_setupQueue = xQueueCreate(1, 1);

}

// Send settings to the specified RTOS queue
void CommandHandler::sendToQueue(const char* queueName, bool status) {
    JsonDocument doc;
    bool newValues = status;

    if (strcmp(queueName, "use_keyqueue") == 0) {
    if (use_keyQueue != NULL) {
        xQueueOverwrite(use_keyQueue, &newValues);
    }
}
else if (strcmp(queueName, "stb_bandul_setupqueue") == 0) {
    if (stb_bandul_setupQueue != NULL) {
        xQueueOverwrite(stb_bandul_setupQueue, &newValues);
    }
}
else if (strcmp(queueName, "stb_mekanikal_setupqueue") == 0) {
    if (stb_mekanikal_setupQueue != NULL) {
        xQueueOverwrite(stb_mekanikal_setupQueue, &newValues);
    }
}

}

//load struct overload function
bool CommandHandler::loadStruct(use_key_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("use_key",doc)){
    structData.state = doc["data"]["state"];
    return true;
}
if(!internal && loadSettings("use_key",doc)){
    structData.state = doc["data"]["state"];
    return true;
}
else if(!hasValue){
    structData.state = setupDoc["use_key"]["default"][0];
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="use_key";
    (*docResult)["data"]["state"]=structData.state;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(stb_bandul_setup_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("stb_bandul_setup",doc)){
    structData.bandul_id = doc["data"]["bandul_id"];
    structData.bandul_length = doc["data"]["bandul_length"];
    return true;
}
if(!internal && loadSettings("stb_bandul_setup",doc)){
    structData.bandul_id = doc["data"]["bandul_id"];
    structData.bandul_length = doc["data"]["bandul_length"];
    return true;
}
else if(!hasValue){
    structData.bandul_id = setupDoc["stb_bandul_setup"]["default"][0];
    structData.bandul_length = setupDoc["stb_bandul_setup"]["default"][1];
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="stb_bandul_setup";
    (*docResult)["data"]["bandul_id"]=structData.bandul_id;
    (*docResult)["data"]["bandul_length"]=structData.bandul_length;
    return false;}


  return false;
}

bool CommandHandler::loadStruct(stb_mekanikal_setup_struct &structData, bool internal, bool loadJson, JsonDocument *docResult) {
JsonDocument doc;
if(!loadJson){
bool hasValue = false;
if(internal && loadSettingsInternal("stb_mekanikal_setup",doc)){
    structData.mekanikal_id = doc["data"]["mekanikal_id"];
    structData.maxrange = doc["data"]["maxrange"];
    structData.opto_timeout_naik = doc["data"]["opto_timeout_naik"];
    structData.pwm_off = doc["data"]["pwm_off"];
    structData.limit_switch = doc["data"]["limit_switch"];
    structData.pressure_switch = doc["data"]["pressure_switch"];
    structData.pwm_resolution = doc["data"]["pwm_resolution"];
    return true;
}
if(!internal && loadSettings("stb_mekanikal_setup",doc)){
    structData.mekanikal_id = doc["data"]["mekanikal_id"];
    structData.maxrange = doc["data"]["maxrange"];
    structData.opto_timeout_naik = doc["data"]["opto_timeout_naik"];
    structData.pwm_off = doc["data"]["pwm_off"];
    structData.limit_switch = doc["data"]["limit_switch"];
    structData.pressure_switch = doc["data"]["pressure_switch"];
    structData.pwm_resolution = doc["data"]["pwm_resolution"];
    return true;
}
else if(!hasValue){
    structData.mekanikal_id = setupDoc["stb_mekanikal_setup"]["default"][0];
    structData.maxrange = setupDoc["stb_mekanikal_setup"]["default"][1];
    structData.opto_timeout_naik = setupDoc["stb_mekanikal_setup"]["default"][2];
    structData.pwm_off = setupDoc["stb_mekanikal_setup"]["default"][3];
    structData.limit_switch = setupDoc["stb_mekanikal_setup"]["default"][4];
    structData.pressure_switch = setupDoc["stb_mekanikal_setup"]["default"][5];
    structData.pwm_resolution = setupDoc["stb_mekanikal_setup"]["default"][6];
    return true;
}
return false;
}

else if(loadJson && docResult!=nullptr){
  (*docResult)["command"]="stb_mekanikal_setup";
    (*docResult)["data"]["mekanikal_id"]=structData.mekanikal_id;
    (*docResult)["data"]["maxrange"]=structData.maxrange;
    (*docResult)["data"]["opto_timeout_naik"]=structData.opto_timeout_naik;
    (*docResult)["data"]["pwm_off"]=structData.pwm_off;
    (*docResult)["data"]["limit_switch"]=structData.limit_switch;
    (*docResult)["data"]["pressure_switch"]=structData.pressure_switch;
    (*docResult)["data"]["pwm_resolution"]=structData.pwm_resolution;
    return false;}


  return false;
}


