#ifndef COMMANDHANDLERQUEUE_H
#define COMMANDHANDLERQUEUE_H
#include <Arduino.h>

extern SemaphoreHandle_t mutex_handler;

// Queue Declarations
extern QueueHandle_t use_keyQueue;
extern QueueHandle_t stb_bandul_setupQueue;
extern QueueHandle_t stb_mekanikal_setupQueue;



// Struct Definitions
#pragma pack(1)

struct headerRadioStruct {
    uint32_t to;
    uint32_t from;
    uint16_t id_message;
    uint8_t type;
    uint16_t key;
    uint16_t commandId;
    uint8_t data [512];
    uint16_t len; 
  };
  
  struct headerCommandStruct {
    uint16_t id_message;
    uint8_t type;
    uint16_t key;
    uint16_t commandId;
    uint8_t data [512];
    uint16_t len; 
  };

struct use_key_struct {
    bool state;
};

struct stb_bandul_setup_struct {
    uint32_t bandul_id;
    float bandul_length;
};

struct stb_mekanikal_setup_struct {
    uint32_t mekanikal_id;
    float maxrange;
    uint16_t opto_timeout_naik;
    int16_t pwm_off;
    bool limit_switch;
    bool pressure_switch;
    uint8_t pwm_resolution;
};

struct restart_struct {
    bool state;
};

struct file_write_struct {
    char path[50];
};

struct file_append_struct {
    char path[50];
};

struct file_delete_struct {
    char path[50];
};

struct stb_move_to_struct {
    int16_t pwm;
    float jarak;
};

struct stb_move_detection_struct {
    int16_t pwm;
    float filter;
    float ignore;
    uint8_t crosscek;
    float maxrange;
};

struct file_list_struct {
    char path[50];
};



#pragma pack()
#endif
